from tkinter import *
from tkinter import ttk
from PIL import Image,ImageTk
from tkinter import messagebox
from classes.Admin_infp import food_info
import datetime
class Password_System:
    def __init__(self,password_window):

#=======For_Designing_Windows=========================================================================================
#=====================================================================================================================
        self.password_window = password_window
        self.password_window.title("Change Password")
        self.password_window.geometry('550x440+0+0')
        self.password_window.resizable("false", "false")
        self.password_window.grab_set()

        self.info_food = food_info()


        def time():
            now = datetime.datetime.now()
            self.date = (now.strftime("%I:%M:%S:%p"))
            self.daa = (now.strftime("%H:%M:%S '/n' %d-%m-%y"))
            self.clock_label = Label(self.password_window, font=('times new roman', 10), fg='black', bg="White", text=self.date)
            self.clock_label.place(x=452, y=24)
            self.clock_label.after(200, time)
        time()

        self.bg2 = ImageTk.PhotoImage(file="C:\\Users\\DELL\\Desktop\\python_projects\\passwordchange.jpg")
        bg = Label(self.password_window,image=self.bg2)
        bg.place(x=0, y=0, relwidth=1, relheight=1)

        self.user_name_label = Label(self.password_window, text="Username",bg="white",font=("times new roman", 15, "bold"))
        self.user_name_label.place(x=65, y=20)

        self.user_name_entry = Entry(self.password_window,highlightbackground='black',highlightthickness="1",font=("times new roman", 11, "bold"))
        self.user_name_entry.place(x=26, y=60)

        self.user_password_label = Label(self.password_window, text="Password",bg="white",font=("times new roman", 15, "bold"))
        self.user_password_label.place(x=260, y=20)

        self.user_password_entry = Entry(self.password_window,highlightbackground='black',highlightthickness="1",font=("times new roman", 11, "bold"))
        self.user_password_entry.place(x=220, y=60)

        self.pasword_res_img = PhotoImage(file="passwod_reset.png")
        self.reset=Button(self.password_window,image=self.pasword_res_img,borderwidth=0,command=self.reset)
        self.reset.place(x=400,y=40,height=50,width=60)
        self.password_window.grab_set()

        self.img_add = PhotoImage(file="pass_add.png")
        self.add = Button(self.password_window,image=self.img_add,borderwidth=0,command=self.Add_new_passwd)
        self.add.place(x=80,y=356,height=60,width=70)

        self.img_update = PhotoImage(file="pass_update.png")
        self.update = Button(self.password_window,image=self.img_update,borderwidth=0,command=self.update_informations)
        self.update.place(x=340,y=356,height=60,width=70)

        self.update_index = ""

        self.password_tree = ttk.Treeview(self.password_window, columns=('username','password'))
        self.password_tree.place(x=24,y=110,width=460,height=240)
        self.password_tree['show'] = 'headings'
        self.password_tree.column('username', width=150)
        self.password_tree.column('password', width=100)

        self.password_tree.heading('username', text="User Name")
        self.password_tree.heading('password', text="Password")

        self.show_admin_information_from_database()

#=======Adding_Scroll_Bar=============================================================================================
#=====================================================================================================================
        self.password_tree_scroll = ttk.Scrollbar(self.password_window, orient="vertical", command=self.password_tree.yview)
        self.password_tree.configure(yscroll=self.password_tree_scroll.set)
        self.password_tree_scroll.place(x=486, y=112, width=40, height=236)
        
        
    def reset(self):
        self.user_name_entry.delete(0,END)
        self.user_password_entry.delete(0,END)

    def show_admin_information_from_database(self):
        self.password_tree.delete(*self.password_tree.get_children())
        data = self.info_food.admin_info()
        for i in data:
            self.password_tree.insert("", "end", text=i[0], value=(i[1],i[2]))
            self.password_tree.bind("<Double-1>", self.on_admin_info_select)

    def on_admin_info_select(self, event):
        selected_row = self.password_tree.selection()[0]
        selected_item = self.password_tree.item(selected_row, 'values')
        self.update_index = self.password_tree.item(selected_row, 'text')

        global update_index
        self.user_name_entry.delete(0, END)
        self.user_name_entry.insert(0, selected_item[0])

        self.user_password_entry.delete(0, END)
        self.user_password_entry.insert(0, selected_item[1])

    def empty_exception(self):
        if self.user_name_entry.get() == "" or self.user_password_entry.get() == "":
            messagebox.showerror("Error", "Entries are empty!!!")
            return True
            pass

    def Add_new_passwd(self):

        if self.empty_exception():
            return True

        else:
            name = self.user_name_entry.get()
            password = self.user_password_entry.get()

            if self.info_food.Add_new_passwd(name,password):
                messagebox.showinfo("Congratulation", "New Admin Logon Added Successfully!")
                self.show_admin_information_from_database()

                self.top_entry_reset()



    def update_informations(self):
        global update_index

        if self.update_index == "":
            messagebox.showerror("Error", "please select the foods item first")

        elif self.empty_exception():
            return True

        else:
            name = self.user_name_entry.get()
            password = self.user_password_entry.get()

            if self.info_food.update_informations(self.update_index, name, password):
                messagebox.showinfo("Item", "updated")

                self.top_entry_reset()

                self.show_admin_information_from_database()
                self.update_index = ""
            else:
                messagebox.showerror("Error", "cannot be updated!!!!")

    def top_entry_reset(self):
        self.user_name_entry.delete(0,END)
        self.user_password_entry.delete(0,END)



def main():
    grocery_window = Tk()
    obj = Password_System(grocery_window)
    grocery_window.mainloop()
if __name__ == '__main__':
    main()

