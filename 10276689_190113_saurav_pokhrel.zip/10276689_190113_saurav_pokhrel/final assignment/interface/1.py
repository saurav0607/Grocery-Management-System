import random
#import pyperclip
a = input("Enter the name: ")
b = input("Enter the num: ")
data = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ#@!$%^&*()_+|/*-+0123456789?><"+a+b
password = ''
for i in range(0,6):
    password = password + random.choice(data)
print(password)


#return password
