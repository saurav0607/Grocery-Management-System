from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from PIL import Image,ImageTk
#from classes.Admin_database import Foods
from classes.Admin_infp import food_info
class fod:
    def __init__(self,window1):
        self.window1 = window1

        #self.FooD = Foods

        self.info_food = food_info()

        self.window1.title("Foods Store")
        self.window1.geometry('1150x700+0+0')
        self.window1.resizable("false","false")



        self.name_label = Label(self.window1, text="Name", font=("times new roman", 15, "bold"))
        self.name_label.place(x=20, y=10)

        self.name_entry = Entry(self.window1, font=("times new roman", 15, "bold"))
        self.name_entry.place(x=20, y=40)

        self.types_label = Label(self.window1, text="Types", font=("times new roman", 15, "bold"))
        self.types_label.place(x=250, y=10)

        self.types_entry = Entry(self.window1, font=("times new roman", 15, "bold"))
        self.types_entry.place(x=250, y=40)

        self.quantity_label = Label(self.window1, text="Quantity", font=("times new roman", 15, "bold"))
        self.quantity_label.place(x=480, y=10)

        self.quantity_entry = Entry(self.window1, font=("times new roman", 15, "bold"))
        self.quantity_entry.place(x=480, y=40)
#=======state="readonly"===============================================================================================
        self.price_label = Label(self.window1, text="Price", font=("times new roman", 15, "bold"))
        self.price_label.place(x=710, y=10)

        self.price_entry = Entry(self.window1, font=("times new roman", 15, "bold"))
        self.price_entry.place(x=710, y=40)

        self.add_cart = Button(self.window1, text="Cart", bg="green", font=("times new roman", 15, "bold"),command=self.cart)
        self.add_cart.place(x=875, y=525, width=80, height=90)

        self.generate_bill = Button(self.window1, text="Generate Bill", bg="green", font=("times new roman", 15, "bold"),command=self.grocery12)
        self.generate_bill.place(x=975, y=525, width=160, height=90)

        #self.delete_children = Button(self.window1, text="Delete All", bg="green", font=("times new roman", 15, "bold"),command=self.del_child)
        #self.delete_children.place(x=875, y=325, width=120, height=90)

        self.label_1 = Label(self.window1,text="A    V    A    I    L    A    B    L    E           I    T    E    M    S",font=("times new roman",20,"bold"))
        self.label_1.place(x=47,y=76)

#=======From_Admin_Stores==============================================================================================
        self.item_tree = ttk.Treeview(self.window1, columns=("name", "type", "price"))
        self.item_tree.place(x=47, y=114, width=780, height=262)
        self.item_tree['show'] = 'headings'
        self.item_tree.column("name", width=200)
        self.item_tree.column("type", width=100)
        self.item_tree.column("price", width=50)

        self.item_tree.heading("name", text="Name")
        self.item_tree.heading("type", text="Type")
        self.item_tree.heading("price", text="Price")


        self.show_foods_tree()

        self.label_2 = Label(self.window1, text="C              A              R              T", font=("times new roman", 20, "bold"))
        self.label_2.place(x=47, y=390)
#======Customer_Selections_To_Bought===================================================================================
        self.cart_tree = ttk.Treeview(self.window1, columns=("name", "type","quantity","price"))
        self.cart_tree.place(x=47, y=425, width=780, height=262)
        self.cart_tree['show'] = 'headings'
        self.cart_tree.column("name", width=175)
        self.cart_tree.column("type", width=25)
        self.cart_tree.column("quantity", width=50)
        self.cart_tree.column("price", width=50)

        self.cart_tree.heading("name", text="Name")
        self.cart_tree.heading("type", text="Type")
        self.cart_tree.heading("quantity", text="Quantity")
        self.cart_tree.heading("price", text="Price")

        self.show_cart_tree()

    def show_foods_tree(self):
        self.item_tree.delete(*self.item_tree.get_children())
        data = self.info_food.show_item()
        for i in data:
            self.item_tree.insert("", "end", text=i[0], value=(i[1],i[2],i[3]))
            self.item_tree.bind("<Double-1>", self.on_foods_select)

    def on_foods_select(self,event):
        selected_row = self.item_tree.selection()[0]
        selected_item = self.item_tree.item(selected_row,'values')
        self.update_index = self.item_tree.item(selected_row,'text')
        print(selected_item)
        self.name_entry.delete(0, END)
        self.name_entry.insert(0, selected_item[0])

        self.types_entry.delete(0, END)
        self.types_entry.insert(0, selected_item[1])

        self.price_entry.delete(0, END)
        self.price_entry.insert(0, selected_item[2])
        self.show_foods_tree()

    def cart(self):
        name = self.name_entry.get()
        types = self.types_entry.get()
        quantity = self.quantity_entry.get()
        rate = self.price_entry.get()


        if self.info_food.cart(name,types,quantity,rate):
            messagebox.showinfo("Congratulation","Items Added To The Cart")
            self.show_cart_tree()

#===========T0_Delete_Entries_Automaticall_After_Items_Is_Added_Into_Cart
            self.name_entry.delete(0,END)
            self.types_entry.delete(0, END)
            self.quantity_entry.delete(0, END)
            self.price_entry.delete(0, END)



    def show_cart_tree(self):
        self.cart_tree.delete(*self.cart_tree.get_children())
        data = self.info_food.show_cart()
        for i in data:
            self.cart_tree.insert("", "end", text=i[0], value=(i[0],i[1],i[2],i[3]))
            #self.item_tree.bind("<Double-1>", self.on_item_select)

    def grocery12(self):
        #self.window.withdraw()
        from classes.Admin_infp import food_info
        self.info = food_info()
        self.window = Toplevel(self.window1)
        self.window.title("Grocery Management System")
        self.window.geometry('1450x790')
        # self.window.configure(bg="white")
        self.window.resizable("false", "false")
        self.window.grab_set()
        self.lebel = Label(self.window, text="C  O  M  M  I  N  G     S  O  O  N!!!!", bg="white",font=("times new roman", 50, "bold"))
        self.lebel.place(x=100, y=300)

        self.bg2 = ImageTk.PhotoImage(file="C:\\Users\\DELL\\Desktop\\python_projects\\grocery_bg.jpg")
        bg = Label(self.window, image=self.bg2).place(x=0, y=0, relwidth=1, relheight=1)

        self.image_foods = PhotoImage(file="foods.png")
        self.button_foods = Button(self.window, image=self.image_foods, fg="white", borderwidth=0, compound=LEFT)
        self.button_foods.place(x=30, y=135, width=220, height=150)

        self.image_cosmetics = PhotoImage(file="cosmetics.png")
        self.button_cosmetics = Button(self.window, image=self.image_cosmetics, borderwidth=0, fg="white",compound=LEFT, command=self.products)
        self.button_cosmetics.place(x=260, y=135, width=220, height=150)

        self.image_drinks = PhotoImage(file="drinks.png")
        self.button_drinks = Button(self.window, image=self.image_drinks, fg="white", borderwidth=0, compound=LEFT,command=self.products)
        self.button_drinks.place(x=492, y=135, width=220, height=150)

        self.image_delete = PhotoImage(file="delete.png")
        self.button_delete = Button(self.window, borderwidth=0, image=self.image_delete, fg="white", compound=LEFT,command=self.button)
        self.button_delete.place(x=956, y=692, width=100, height=65)

        self.image_add = PhotoImage(file="add.png")
        self.button_add = Button(self.window, borderwidth=0, image=self.image_add, fg="white", compound=LEFT,command=self.button)
        self.button_add.place(x=1148, y=692, width=100, height=65)

        self.image_print = PhotoImage(file="print.png")
        self.button_print = Button(self.window, borderwidth=0, image=self.image_print, fg="white", compound=LEFT,command=self.button)
        self.button_print.place(x=1315, y=692, width=100, height=65)

        self.customer_Name = Label(self.window, text="Customer Name", font=("times new roamn", 15, "bold"), bg="white")
        self.customer_Name.place(x=50, y=338)

        self.customer_Name_Entry = Entry(self.window, font=("times new roman", 15), bg="lightgray")
        self.customer_Name_Entry.place(x=50, y=380, width=160)

        self.customer_Id = Label(self.window, text="Customer Id", font=("times new roamn", 15, "bold"), bg="white")
        self.customer_Id.place(x=375, y=338)

        self.customer_Id_Entry = Entry(self.window, font=("times new roman", 15), bg="lightgray")
        self.customer_Id_Entry.place(x=375, y=380, width=140)

        self.customer_Number = Label(self.window, text="Customer Number", font=("times new roamn", 15, "bold"),
                                     bg="white")
        self.customer_Number.place(x=628, y=338)

        self.customer_Number_Entry = Entry(self.window, font=("times new roman", 15), bg="lightgray")
        self.customer_Number_Entry.place(x=630, y=380, width=172)

        self.item_tree1 = ttk.Treeview(self.window, columns=('name', 'type', 'quantity', 'price', 'total_price'))
        self.item_tree1.place(x=47, y=478, width=780, height=262)
        self.item_tree1['show'] = 'headings'
        self.item_tree1.column('name', width=200)
        self.item_tree1.column('type', width=100)
        self.item_tree1.column('quantity', width=100)
        self.item_tree1.column('price', width=50)
        self.item_tree1.column('total_price', width=50)

        self.item_tree1.heading('name', text="Name")
        self.item_tree1.heading('type', text="Type")
        self.item_tree1.heading('quantity', text="Quantity")
        self.item_tree1.heading('price', text="Price")
        self.item_tree1.heading('total_price', text="Total_Price")

        name = self.name_entry.get()
        types = self.types_entry.get()
        quantity = self.quantity_entry.get()
        rate = self.price_entry.get()

        if self.info.cart(name, types, quantity, rate):
            #messagebox.showinfo("Congratulation", "Items Added To The Cart")
            self.show_tree1()

    def show_tree1(self):
        #self.item_tree1.delete(*self.item_tree1.get_children())
        data = self.info_food.show_cart()
        for i in data:
            self.item_tree1.insert("", "end", text=i[0], value=(i[0],i[1],i[2],i[3]))
            #self.item_tree.bind("<Double-1>", self.on_item_select)





    def products(self):
        messagebox.showinfo("Hey", "This is products!")
#===To_Delete_All_Children_Of_TreeView================================================================================
    def del_child(self):
        for i in self.item_tree.get_children():
            self.item_tree.delete(i)
        #self.cart_tree.delete(*self.cart_tree.get_children())




    def button(self):
        messagebox.showinfo("Hey", "Deleted Babe!!!!!! :)")

    #def foods(self):



    #def foods_products(self):
        #self.new_window = Toplevel(self.window)
        #fod(self.new_window)






def main():
    window = Tk()
    obj =fod(window)
    window.mainloop()


if __name__ == '__main__':
    main()

