from tkinter import *
from tkinter import ttk
from interface.foods import fod
from classes.Admin_infp import food_info
from PIL import Image,ImageTk
import datetime
global update_index
update_index = ""
from tkinter import messagebox
class Grocery_System:
    def __init__(self,grocery_window):

#======To_Import_Class_Of_Admin_Info=================================================================================
#====================================================================================================================
        self.foods = food_info()

#=======For_Designing_Windows=========================================================================================
#=====================================================================================================================
        self.grocery_window = grocery_window
        self.grocery_window.title("Grocery Management System")
        self.grocery_window.geometry('1450x790+0+0')
        self.grocery_window.resizable("false", "false")


        def time():
            now = datetime.datetime.now()
            self.date = (now.strftime("%I:%M:%S:%p"))
            self.daa = (now.strftime("%H:%M:%S '/n' %d-%m-%y"))
            self.clock_label = Label(self.grocery_window, font=('times new roman', 15), fg='black', bg="White", text=self.date)
            self.clock_label.place(x=1305, y=65)
            self.clock_label.after(200, time)
        time()






#=======Designing_Label_Entries_Buttons===============================================================================
#=====================================================================================================================
        self.bg2 = ImageTk.PhotoImage(file="C:\\Users\\DELL\\Desktop\\python_projects\\grocery_bg.jpg")
        bg = Label(self.grocery_window, image=self.bg2).place(x=0, y=0, relwidth=1, relheight=1)

        self.image_foods = PhotoImage(file="foods.png")
        self.button_foods = Button(self.grocery_window,image=self.image_foods,fg="white",borderwidth=0,compound=LEFT,command=self.foods_products)
        self.button_foods.place(x=30,y=135,width=220,height=150)

        self.image_cosmetics = PhotoImage(file="cosmetics.png")
        self.button_cosmetics = Button(self.grocery_window, image=self.image_cosmetics,borderwidth=0,fg="white", compound=LEFT,command=self.cosmetic_products)
        self.button_cosmetics.place(x=260, y=135, width=220, height=150)

        self.image_drinks = PhotoImage(file="drinks.png")
        self.button_drinks = Button(self.grocery_window, image=self.image_drinks, fg="white",borderwidth=0,compound=LEFT,command=self.bread_products)
        self.button_drinks.place(x=492, y=135, width=220, height=150)

        self.image_delete = PhotoImage(file="delete.png")
        self.button_delete = Button(self.grocery_window, borderwidth=0,image=self.image_delete,fg="white",compound=LEFT,command=self.delete)
        self.button_delete.place(x=956, y=692, width=100, height=65)

        self.image_add = PhotoImage(file="add.png")
        self.button_add = Button(self.grocery_window, borderwidth=0, image=self.image_add, fg="white", compound=LEFT,command=self.Confirm)
        self.button_add.place(x=1148, y=692, width=100, height=65)

        self.logout = Button(self.grocery_window, borderwidth=0, text="L o g o u t", fg="Black", bg="White", compound=LEFT,command=self.Logout)
        self.logout.place(x=35, y=50)

        self.image_print = PhotoImage(file="print.png")
        self.button_print = Button(self.grocery_window, borderwidth=0, image=self.image_print, fg="white", compound=LEFT,command=self.check)
        self.button_print.place(x=1315, y=692, width=100, height=65)

        self.customer_Name = Label(self.grocery_window, text="Customer Name", font=("times new roamn", 15,"bold"), bg="white")
        self.customer_Name.place(x=50, y=338)

        self.customer_Name_Entry=Entry(self.grocery_window,font=("times new roman",15),bg="lightgray")
        self.customer_Name_Entry.place(x=50,y=380,width=160)

        self.customer_Id = Label(self.grocery_window, text="Customer Id", font=("times new roamn", 15, "bold"), bg="white")
        self.customer_Id.place(x=375, y=338)



        self.customer_Id_Entry = Entry(self.grocery_window, font=("times new roman", 15), bg="lightgray")
        self.customer_Id_Entry.place(x=375, y=380, width=140)

        self.customer_Number = Label(self.grocery_window, text="Customer Number", font=("times new roamn", 15, "bold"), bg="white")
        self.customer_Number.place(x=628, y=338)

        self.customer_Number_Entry = Entry(self.grocery_window, font=("times new roman", 15), bg="lightgray")
        self.customer_Number_Entry.place(x=630, y=380, width=172)

#=======Tree_View_Of_Grocery_Windows==================================================================================
#=====================================================================================================================
        self.grocery_tree = ttk.Treeview(self.grocery_window, columns=('name', 'type', 'quantity','price','total','CustomerName'))
        self.grocery_tree.place(x=47,y=478,width=738,height=262)
        self.grocery_tree['show'] = 'headings'
        self.grocery_tree.column('name', width=150)
        self.grocery_tree.column('type', width=100)
        self.grocery_tree.column('quantity', width=50)
        self.grocery_tree.column('price', width=50)
        self.grocery_tree.column('total', width=50)
        self.grocery_tree.column('CustomerName', width=100)

        self.grocery_tree.heading('name', text="Name")
        self.grocery_tree.heading('type', text="Type")
        self.grocery_tree.heading('quantity', text="Quantity")
        self.grocery_tree.heading('price', text="Price")
        self.grocery_tree.heading('total', text="Total")
        self.grocery_tree.heading('CustomerName', text="Customer_Name")

        self.lol()

#=======Adding_Scroll_Bar=============================================================================================
#=====================================================================================================================
        self.grocery_tree_scroll = ttk.Scrollbar(self.grocery_window, orient="vertical", command=self.grocery_tree.yview)
        self.grocery_tree.configure(yscroll=self.grocery_tree_scroll.set)
        self.grocery_tree_scroll.place(x=788, y=478, width=40, height=260)

#===To_Insert_Items_Brougth_By_Customer_into_Database=================================================================
#=====================================================================================================================

    def Confirm(self):
        data = self.grocery_tree.get_children()
        if len(self.grocery_tree.get_children()) == 0 or self.customer_Name_Entry.get() == "" or self.customer_Id_Entry.get() == "" or self.customer_Number_Entry.get() == "":
            messagebox.showerror("Error","There are no any data in Basket")
        else:
            for i in data:
                order = self.grocery_tree.item(i,"values")
                if self.foods.Confirm(order[0],order[1],order[2],order[3],order[4],order[5]):
                    pass
            def message():
                messagebox.showinfo("Congratulation","Items successfully added to database")
                self.grocery_tree.delete(*self.grocery_tree.get_children())
                self.customer_Name_Entry.delete(0, END)
                self.customer_Number_Entry.delete(0, END)
                self.customer_Id_Entry.delete(0, END)
                self.frame.destroy()
                return True
            message()

    def bill_res(self):
        self.frame.destroy()


    def check(self):
        if len(self.grocery_tree.get_children()) == 0:
            messagebox.showerror("Error","Please Brought To Make Bill")
        else:
            self.frame = Frame(self.grocery_window,bg="White")
            self.frame.place(x=960,y=136,height=545,width=455)

            self.bt_img = PhotoImage(file="bill_res.png")
            self.bt = Button(self.frame,image=self.bt_img,bg="White",borderwidth=0,command=self.bill_res)
            self.bt.place(x=380,y=40,height=30,width=32)

            self.bill_tree = ttk.Treeview(self.frame,columns=('name', 'type', 'quantity', 'price', 'total'))
            self.bill_tree.place(x=0, y=175, width=455, height=316)
            self.bill_tree['show'] = 'headings'
            self.bill_tree.column('name', width=150)
            self.bill_tree.column('type', width=100)
            self.bill_tree.column('quantity', width=50)
            self.bill_tree.column('price', width=50)
            self.bill_tree.column('total', width=50)

            self.bill_tree.heading('name', text="Name")
            self.bill_tree.heading('type', text="Type")
            self.bill_tree.heading('quantity', text="Quantity")
            self.bill_tree.heading('price', text="Price")
            self.bill_tree.heading('total', text="Total")

            orders = self.grocery_tree.get_children()
            total = 0
            list = []
            for i in orders:
                order = self.grocery_tree.item(i,'values')
                # items = order[0] + "\t" +order[1] + "\t" +order[2] + "\t" + order[3] + "\t" +order[4]

                self.bill_tree.insert("","end",text=i[0],values=(order[0],order[1],order[2],order[3],order[4]))
                # self.l = Label(self.frame,text = items,bg="White")
                # self.l.place(x=0,y=00)
                #print(items)
                amnt = float(order[2]) * float(order[3])
                total += amnt
                lb_total_price = Label(self.frame, text = total, bg="White", font=("times new roman", 11, "bold"))
                lb_total_price.place(x=380, y=520)
                print(amnt)

            data = len(self.grocery_tree.get_children())
            ddd = 0
            for i in range(0,data+1):
                print(i)

                lb_tot_num = Label(self.frame,text = i,bg="White",font=("times new roman",11,"bold"))
                lb_tot_num.place(x=280,y=520)

                self.word = Label(self.frame, text="--------------------------------------------------",font=("times new roman", 20, "bold"), bg="white")
                self.word.place(x=0, y=490)

                lb_tot = Label(self.frame, text="Total = ",bg="White",font=("times new roman",11,"bold"))
                lb_tot.place(x=320,y=520)

                lb_tot_quan = Label(self.frame, text="Total Items = ", bg="White", font=("times new roman", 11, "bold"))
                lb_tot_quan.place(x=180, y=520)



            self.img = PhotoImage(file="Logo_Kollywood.png")

            ddd = self.customer_Name_Entry.get()

            self.koly_btn_title = Button(self.frame,bg="White",image=self.img,borderwidth=0)
            self.koly_btn_title.place(x=176,y=8,height=100,width=100)

            self.word = Label(self.frame, text="--------------------------------------------------", font=("times new roman", 20, "bold"), bg="white")
            self.word.place(x=0,y=110)

            self.word = Label(self.frame, text="--------------------------------------------------",font=("times new roman", 20, "bold"), bg="white")
            self.word.place(x=0, y=140)

            self.cu_name = Label(self.frame,text="Customer Name =",bg="White",font=("times new roman",11,"bold"))
            self.cu_name.place(x=20,y=135)

            self.name_grab = Label(self.frame, text=ddd, font=("times new roman", 11, "bold"), bg="white")
            self.name_grab.place(x=150, y=135)

            self.time = Label(self.frame, text="Time =", font=("times new roman", 11, "bold"), bg="white")
            self.time.place(x=330, y=135)

            self.date = Label(self.frame, text="Date =", font=("times new roman", 11, "bold"), bg="white")
            self.date.place(x=340, y=5)



            def time():
                now = datetime.datetime.now()
                self.date = (now.strftime("%I:%M %p"))
                self.daa = (now.strftime("%d-%m-%y"))
                self.clock_label = Label(self.frame, font=('times new roman', 11), fg='black', bg="White", text=self.date)
                self.date_label = Label(self.frame, font=('times new roman', 11), fg='black', bg="White",text=self.daa)
                self.date_label.place(x=394,y=5)
                self.clock_label.place(x=390, y=135)
                self.clock_label.after(200, time)
            time()


    def Logout(self):
        from interface.login_ import Sign
        self.ttt = Toplevel(self.grocery_window)
        self.grocery_window.withdraw()
        Sign(self.ttt)

    def reset(self):
        if len(self.grocery_tree.get_children()) == 0:
            messagebox.showerror("Error","Error")
            return True

    def delete(self):
        selected_items = self.grocery_tree.selection()
        for selected_item in selected_items:
            self.grocery_tree.delete(selected_item)

    def lol(self):
        self.grocery_tree.bind("<Double-1>",self.on_select)
        self.grocery_tree.delete(*self.grocery_tree.get_children())

    def on_select(self, event):
        selected_row = self.grocery_tree.selection()[0]
        selected_item = self.grocery_tree.item(selected_row, 'values')
        self.update_index = self.grocery_tree.item(selected_row, 'text')
        print(selected_item)



#=====================================================================================================================
#=====================================================================================================================
#===============================================WINDOWS_FOODS_START===================================================
#=====================================================================================================================
#=====================================================================================================================

#===Making_Functions_For_Bill_For_Grocery_Windows_From_Foods_Store====================================================
#=====================================================================================================================
    def Bill_For_Grocery(self):
        if self.name_entry.get() != "" or self.types_entry.get() != "" or self.quantity_entry.get() != "" or self.price_entry.get() != "":
            messagebox.showerror("error", "PLease add first")


        elif len(self.cart_tree.get_children()) == 0:
            messagebox.showerror("Error", "No items in the cart")
            return True
        else:
            name = self.name_entry.get()
            types = self.types_entry.get()
            quantity = self.quantity_entry.get()
            rate = self.price_entry.get()
            username = self.customer_Name_Entry.get()

            q = float(0)
            p = float(0)

            total2 = q*p
            print(total2)
            total = 55


            if self.name_entry.get() != "" or self.types_entry.get() != "" or self.quantity_entry.get() != "" or self.price_entry.get() != "":
                messagebox.showerror("error","PLease add first")


            elif len(self.cart_tree.get_children()) == 0:
                messagebox.showerror("Error","No items in the cart")
                return True


            else:
                messagebox.showinfo("Congratulation", "Items Added To The Bill")
                self.show_Bill_For_Grocery_tree()
                self.window_foods.destroy()
                return True

#==Importing_From_List_Of_Items_Added_To_Cart_From_Foods_Store_And_Putting_Them_In_Tree_View_Of_Grocery_Windows=======
#=====================================================================================================================

    def show_Bill_For_Grocery_tree(self):
        data = self.info_food.show_cart()
        for i in data:
            self.grocery_tree.insert("", "end", text=i[0], value=i)
            #self.bill_tree.insert("", "end", text=i[0], value=i)


#===Making_New_Window_For_Foods_Products==============================================================================
#=====================================================================================================================
    def foods_products(self):
        if self.customer_Name_Entry.get() == "" or self.customer_Id_Entry.get() == "" or self.customer_Number_Entry.get() == "":
            messagebox.showerror("Error","Please fill the customer details")
        else:
            from classes.Admin_infp import food_info
#=======For_Designing_Windows=========================================================================================
#=====================================================================================================================
            self.window_foods = Toplevel(self.grocery_window)
            self.info_food = food_info()
            self.window_foods.title("Foods Store")
            self.window_foods.geometry('1350x800')
            self.window_foods.resizable("false", "false")
            self.window_foods.grab_set()

            def time():
                now = datetime.datetime.now()
                self.date = (now.strftime("%I:%M:%S:%p"))
                self.daa = (now.strftime("%H:%M:%S '/n' %d-%m-%y"))
                self.clock_label = Label(self.window_foods, font=('times new roman', 15), fg='black', bg="White",text=self.date)
                self.clock_label.place(x=1200, y=70)
                self.clock_label.after(200, time)
            time()

#=======Designing_Label_Entries_Buttons===============================================================================
#=====================================================================================================================
            self.wn_back=PhotoImage(file="Foods _bg.png")
            bg3 = Label(self.window_foods, image=self.wn_back).place(x=0, y=0, relwidth=1, relheight=1)

            self.name_label = Label(self.window_foods, text="Item Name",bg="white",font=("times new roman", 20, "bold"))
            self.name_label.place(x=130, y=115)

            self.name_entry = Entry(self.window_foods,bg="lightgray",font=("times new roman", 15, "bold"))
            self.name_entry.place(x=100, y=154)

            self.types_label = Label(self.window_foods,bg="white",text="Item Type", font=("times new roman", 20, "bold"))
            self.types_label.place(x=460, y=115)

            self.types_entry = Entry(self.window_foods,bg="lightgray",font=("times new roman", 15, "bold"))
            self.types_entry.place(x=420, y=154)

            self.quantity_label = Label(self.window_foods,bg="white",text="Item Quantity", font=("times new roman", 20, "bold"))
            self.quantity_label.place(x=750, y=115)

            self.quantity_entry = Entry(self.window_foods,bg="lightgray",font=("times new roman", 15, "bold"))
            self.quantity_entry.place(x=732, y=154)

            self.price_label = Label(self.window_foods, text="Item Price",bg="white",font=("times new roman", 20, "bold"))
            self.price_label.place(x=1075, y=115)

            self.price_entry = Entry(self.window_foods,bg="lightgray",font=("times new roman", 15, "bold"))
            self.price_entry.place(x=1036, y=154)

            self.search_entry = Entry(self.window_foods, bg="lightgray", font=("times new roman", 15, "bold"))
            self.search_entry.place(x=895, y=380)

            self.search_img = PhotoImage(file="search.png")
            self.search_Button = Button(self.window_foods, image=self.search_img, bg="white", borderwidth=0,font=("times new roman", 15, "bold"),command=self.searchfoods)
            self.search_Button.place(x=1150, y=350, width=80, height=70)

            self.search_reset = Button(self.window_foods,text="R e s e t",bg="white", borderwidth=0,font=("times new roman", 12, "bold"),command=self.search_reset)
            self.search_reset.place(x=1225, y=320)

            self.foods_update_img = PhotoImage(file="Foods_Update.png")
            self.Update_foods = Button(self.window_foods,borderwidth=0,image=self.foods_update_img,command=self.update_cart)
            self.Update_foods.place(x=848, y=590, width=475, height=50)

            self.cart_img = PhotoImage(file="cart.png")
            self.add_cart = Button(self.window_foods,image=self.cart_img,borderwidth=0,command=self.cart_foods)
            self.add_cart.place(x=850, y=650, width=140, height=120)

            self.delete_cart_img = PhotoImage(file="delete_cart.png")
            self.cart_delete = Button(self.window_foods,borderwidth=0,image=self.delete_cart_img,command=self.remove_foods)
            self.cart_delete.place(x=1016, y=650, width=140, height=120)

            self.Bill_img = PhotoImage(file="Bill.png")
            self.generate_Bill_For_Grocery = Button(self.window_foods,image=self.Bill_img,borderwidth=0,command=self.Bill_For_Grocery)
            self.generate_Bill_For_Grocery.place(x=1178, y=650, width=140, height=120)

#==========Tree_View_In_Foods_StoreWhich_Contains_Items_Added_From_Admin_Stores======================================
#=====================================================================================================================
            self.item_tree = ttk.Treeview(self.window_foods, columns=("name", "type", "price"))
            self.item_tree.place(x=38, y=235, width=752, height=240)
            self.item_tree['show'] = 'headings'
            self.item_tree.column("name", width=200)
            self.item_tree.column("type", width=100)
            self.item_tree.column("price", width=50)

            self.item_tree.heading("name", text="Name")
            self.item_tree.heading("type", text="Type")
            self.item_tree.heading("price", text="Price")

            self.show_foods_from_admin_on_tree_view()
#===========Adding_Scroll_Bar========================================================================================
#====================================================================================================================
            self.item_tree_scroll = ttk.Scrollbar(self.window_foods, orient="vertical", command=self.item_tree.yview)
            self.item_tree.configure(yscroll=self.item_tree_scroll.set)
            self.item_tree_scroll.place(x=792, y=236, width=40, height=240)

#===========Tree_View_In_Foods_Store_Where_Customer_Add_To_Cart_To_Bought=============================================
#=====================================================================================================================
            self.cart_tree = ttk.Treeview(self.window_foods, columns=("name", "type", "quantity", "price"))
            self.cart_tree.place(x=42, y=527, width=752, height=240)
            self.cart_tree['show'] = 'headings'
            self.cart_tree.column("name", width=175)
            self.cart_tree.column("type", width=25)
            self.cart_tree.column("quantity", width=50)
            self.cart_tree.column("price", width=50)

            self.cart_tree.heading("name", text="Name")
            self.cart_tree.heading("type", text="Type")
            self.cart_tree.heading("quantity", text="Quantity")
            self.cart_tree.heading("price", text="Price")

            self.show_foods_cart_tree()

#===========Adding_Scroll_Bar=========================================================================================
#=====================================================================================================================
            self.cartscroll = ttk.Scrollbar(self.window_foods,orient="vertical",command=self.cart_tree.yview)
            self.cart_tree.configure(yscroll=self.cartscroll.set)
            self.cartscroll.place(x=795,y=528,width=40,height=240)


#==Importing_Foods_Added_By_Admin=====================================================================================
#=====================================================================================================================
    def show_foods_from_admin_on_tree_view(self):
        self.item_tree.delete(*self.item_tree.get_children())
        data = self.info_food.show_item()
        for i in data:
            self.item_tree.insert("", "end", text=i[0], value=(i[1], i[2], i[3]))
            self.item_tree.bind("<Double-1>", self.on_foods_select_on_tree_view_where_admin_foods_displayed)

#===Making_Functions_To_Update_Foods_From_Admin_Tree_Root_To_Display_In_Entries======================================
#=====================================================================================================================
    def on_foods_select_on_tree_view_where_admin_foods_displayed(self, event):
        selected_row = self.item_tree.selection()[0]
        selected_item = self.item_tree.item(selected_row, 'values')
        self.update_index = self.item_tree.item(selected_row, 'text')
        print(selected_item)
        self.name_entry.delete(0, END)
        self.name_entry.insert(0, selected_item[0])

        self.types_entry.delete(0, END)
        self.types_entry.insert(0, selected_item[1])

        self.price_entry.delete(0, END)
        self.price_entry.insert(0, selected_item[2])
        #self.show_foods_from_admin_on_tree_view()


#==To_Import_Foods_On_Cart_Tree=======================================================================================
#=====================================================================================================================
    def show_foods_cart_tree(self):
        self.cart_tree.delete(*self.cart_tree.get_children())
        data = self.info_food.show_cart()
        for i in data:
            self.cart_tree.insert("", "end", text=i[0], value=i)
            self.cart_tree.bind("<Double-1>",self.on_cart_select)

#===Making_Functions_To_Update_Foods_From_Cart_Tree_Root_To_Display_In_Entries========================================
#=====================================================================================================================
    def on_cart_select(self,event):
        selected_row = self.cart_tree.selection()[0]
        global update_index
        update_index = (self.cart_tree.index(selected_row))
        all_item = self.info_food.show_cart()
        selected_item = all_item[update_index]
        print(selected_item)

        self.name_entry.delete(0,END)
        self.name_entry.insert(0,selected_item[0])

        self.types_entry.delete(0,END)
        self.types_entry.insert(0,selected_item[1])

        self.quantity_entry.delete(0,END)
        self.quantity_entry.insert(0,selected_item[2])

        self.price_entry.delete(0,END)
        self.price_entry.insert(0,selected_item[3])



#===To_Update_Foods_On_Cart_Tree======================================================================================
#=====================================================================================================================
    def update_cart(self):
        global update_index
        if update_index == "":
            messagebox.showerror("Error","please select the cart items first")


        else:
            name = self.name_entry.get()
            types = self.types_entry.get()
            quantity = self.quantity_entry.get()
            rate = self.price_entry.get()
            username = self.customer_Name_Entry.get()

            global total

            try:
                q = float(self.quantity_entry.get())
                p = float(self.price_entry.get())

                total = q * p
            except ValueError:
                messagebox.showerror("Error","quantity or price can't be strings")
                self.quantity_entry.delete(0,END)
                return True

            if self.name_entry.get() == "" or self.types_entry.get() == "" or self.quantity_entry.get() == "" or self.price_entry.get() == "":
                messagebox.showerror("Error", "All Entries Are Not Filled")
            else:
                name = self.name_entry.get()
                type = self.types_entry.get()
                quantity = self.quantity_entry.get()
                rate = self.price_entry.get()
                if self.info_food.update_cart(update_index,name,type,quantity,rate,total):
                    messagebox.showinfo("Info","Items Updated")
                    self.show_foods_cart_tree()
                    update_index = ""

                self.name_entry.delete(0,END)
                self.types_entry.delete(0,END)
                self.quantity_entry.delete(0,END)
                self.price_entry.delete(0,END)

#===To_Add_Foods_On_Cart_Tree=========================================================================================
#=====================================================================================================================
    def cart_foods(self):
        if self.name_entry.get() == "" or self.types_entry.get() == "" or self.quantity_entry.get() == "" or self.price_entry.get() == "":
            messagebox.showerror("Error", "All Entries Are Not Filled")
            pass
        else:
            name = self.name_entry.get()
            types = self.types_entry.get()
            quantity = self.quantity_entry.get()
            rate = self.price_entry.get()
            username = self.customer_Name_Entry.get()

            global total

            try:
                q = float(self.quantity_entry.get())
                p = float(self.price_entry.get())

                total = q * p
            except ValueError:
                messagebox.showerror("Error","quantity or price can't be strings")
                self.quantity_entry.delete(0,END)
                return True

            if self.name_entry.get() == "" or self.types_entry.get() == "" or self.quantity_entry.get() == "" or self.price_entry.get() == "":
                messagebox.showerror("Error", "All Entries Are Not Filled")


            elif self.info_food.cart_foods(name, types, quantity, username,rate,total):
                self.show_foods_cart_tree()
                self.name_entry.delete(0, END)
                self.types_entry.delete(0, END)
                self.quantity_entry.delete(0, END)
                self.price_entry.delete(0, END)

    def remove_foods(self):
        name = self.name_entry.get()
        type = self.types_entry.get()
        quantity = self.quantity_entry.get()
        rate = self.price_entry.get()
        selected_items = self.cart_tree.selection()

        for selected_item in selected_items:
            self.cart_tree.delete(selected_item)
            self.info_food.remove_selected_cart(name, type, quantity, rate)
            self.show_foods_cart_tree()
            self.name_entry.delete(0, END)
            self.types_entry.delete(0, END)
            self.quantity_entry.delete(0, END)
            self.price_entry.delete(0, END)

    def searchfoods(self):
        name = self.search_entry.get()
        if self.search_entry.get() == "":
            messagebox.showerror("Error","Please fill give the item name to search!")
        else:
            self.item_tree.delete(*self.item_tree.get_children())
            data = self.info_food.Grocery_Foods_Search(name)
            for i in data:
                self.item_tree.insert("", "end", text=i[0], value=(i[1], i[2], i[3]))
                self.item_tree.bind("<Double-1>", self.on_foods_select_on_tree_view_where_admin_foods_displayed)

    def search_reset(self):
        self.search_entry.delete(0,END)
        self.show_foods_from_admin_on_tree_view()


#=====================================================================================================================
#=====================================================================================================================
#===============================================WINDOW_FOODS_END======================================================
#=====================================================================================================================
#=====================================================================================================================





#=====================================================================================================================
#=====================================================================================================================
#===============================================WINDOWS_COSMETIC_START===================================================
#=====================================================================================================================
#=====================================================================================================================

#===Making_Functions_For_Bill_For_Grocery_Windows_From_Cosmetic_Store====================================================
#=====================================================================================================================
    def Bill_For_Cosmetic(self):
        if self.name_entry.get() != "" or self.types_entry.get() != "" or self.quantity_entry.get() != "" or self.price_entry.get() != "":
            messagebox.showerror("error","PLease add first")


        elif len(self.cosmetic_cart.get_children()) == 0:
            messagebox.showerror("Error","No items in the cart")
            return True
        else:
            name = self.name_entry.get()
            types = self.types_entry.get()
            quantity = self.quantity_entry.get()
            username = self.customer_Name_Entry.get()
            rate = self.price_entry.get()
            q = float(0)
            p = float(0)

            total = q * p
            print(total)

            if self.name_entry.get() != "" or self.types_entry.get() != "" or self.quantity_entry.get() != "" or self.price_entry.get() != "":
                messagebox.showerror("error", "PLease add first")


            elif len(self.cosmetic_cart.get_children()) == 0:
                messagebox.showerror("Error", "No items in the cart")
                return True

            else:
                messagebox.showinfo("Congratulation", "Items Added To The Bill")
                self.show_Bill_From_Cosmetic_tree()
                self.window_cosmetic.destroy()
                return True


#==Importing_From_List_Of_Items_Added_To_Cart_From_Cosmetic_Store_And_Putting_Them_In_Tree_View_Of_Grocery_Windows====
#=====================================================================================================================
    def show_Bill_From_Cosmetic_tree(self):
        data = self.info_food.show_cart()
        for i in data:
            self.grocery_tree.insert("", "end", text=i[0], value=i)


#===Making_New_Window_For_Cosmetic_Products==============================================================================
#=====================================================================================================================
    def cosmetic_products(self):
        if self.customer_Name_Entry.get() == "" or self.customer_Id_Entry.get() == "" or self.customer_Number_Entry.get() == "":
            messagebox.showerror("Error","Please fill the customer details")
        else:
            from classes.Admin_infp import food_info
#=======For_Designing_Windows=========================================================================================
#=====================================================================================================================
            self.window_cosmetic = Toplevel(self.grocery_window)
            self.info_food = food_info()
            self.window_cosmetic.title("Foods Store")
            self.window_cosmetic.geometry('1350x800')
            self.window_cosmetic.resizable("false", "false")
            self.window_cosmetic.grab_set()

            def time():
                now = datetime.datetime.now()
                self.date = (now.strftime("%I:%M:%S:%p"))
                self.daa = (now.strftime("%H:%M:%S '/n' %d-%m-%y"))
                self.clock_label = Label(self.window_cosmetic, font=('times new roman', 15), fg='black', bg="White",text=self.date)
                self.clock_label.place(x=1160, y=70)
                self.clock_label.after(200, time)
            time()

#=======Designing_Label_Entries_Buttons===============================================================================
#=====================================================================================================================
            self.wn_back=PhotoImage(file="cosmetics_store.png")
            bg3 = Label(self.window_cosmetic, image=self.wn_back).place(x=0, y=0, relwidth=1, relheight=1)

            self.name_label = Label(self.window_cosmetic, text="Item Name",bg="white",font=("times new roman", 20, "bold"))
            self.name_label.place(x=130, y=115)

            self.name_entry = Entry(self.window_cosmetic,bg="lightgray",font=("times new roman", 15, "bold"))
            self.name_entry.place(x=100, y=154)

            self.types_label = Label(self.window_cosmetic,bg="white",text="Item Type", font=("times new roman", 20, "bold"))
            self.types_label.place(x=460, y=115)

            self.types_entry = Entry(self.window_cosmetic,bg="lightgray",font=("times new roman", 15, "bold"))
            self.types_entry.place(x=420, y=154)

            self.quantity_label = Label(self.window_cosmetic,bg="white",text="Item Quantity", font=("times new roman", 20, "bold"))
            self.quantity_label.place(x=750, y=115)

            self.quantity_entry = Entry(self.window_cosmetic,bg="lightgray",font=("times new roman", 15, "bold"))
            self.quantity_entry.place(x=732, y=154)

            self.price_label = Label(self.window_cosmetic, text="Item Price",bg="white",font=("times new roman", 20, "bold"))
            self.price_label.place(x=1075, y=115)

            self.price_entry = Entry(self.window_cosmetic,bg="lightgray",font=("times new roman", 15, "bold"))
            self.price_entry.place(x=1036, y=154)

            self.search_entry = Entry(self.window_cosmetic, bg="lightgray", font=("times new roman", 15, "bold"))
            self.search_entry.place(x=895, y=380)

            self.search_img = PhotoImage(file="search.png")
            self.search_Button = Button(self.window_cosmetic, image=self.search_img, bg="white", borderwidth=0,font=("times new roman", 15, "bold"),command=self.search_cosmetics)
            self.search_Button.place(x=1150, y=350, width=80, height=70)

            self.search_reset = Button(self.window_cosmetic, text="R e s e t", bg="white", borderwidth=0,font=("times new roman", 12, "bold"),command=self.cosmetics_reset)
            self.search_reset.place(x=1225, y=320)

            self.cosmetic_update_img = PhotoImage(file="Foods_Update.png")
            self.Update_cosmetic = Button(self.window_cosmetic,borderwidth=0,image=self.cosmetic_update_img,command=self.update_cosmetics)
            self.Update_cosmetic.place(x=848, y=590, width=475, height=50)

            self.cart_img = PhotoImage(file="cart.png")
            self.add_cart = Button(self.window_cosmetic,image=self.cart_img,borderwidth=0,command=self.cart_cosmetic)
            self.add_cart.place(x=850, y=650, width=140, height=120)

            self.delete_cart_img = PhotoImage(file="delete_cart.png")
            self.cart_delete = Button(self.window_cosmetic,borderwidth=0,image=self.delete_cart_img,command=self.remove_cosmetics)
            self.cart_delete.place(x=1016, y=650, width=140, height=120)

            self.Bill_img = PhotoImage(file="Bill.png")
            self.generate_Bill_For_Grocery = Button(self.window_cosmetic,image=self.Bill_img,borderwidth=0,command=self.Bill_For_Cosmetic)
            self.generate_Bill_For_Grocery.place(x=1178, y=650, width=140, height=120)

#==========Tree_View_In_Cosmetic_Store_Which_Contains_Items_Added_From_Admin_Stores===================================
#=====================================================================================================================
            self.cosmetic_tree = ttk.Treeview(self.window_cosmetic, columns=("name", "type", "price"))
            self.cosmetic_tree.place(x=38, y=235, width=752, height=240)
            self.cosmetic_tree['show'] = 'headings'
            self.cosmetic_tree.column("name", width=200)
            self.cosmetic_tree.column("type", width=100)
            self.cosmetic_tree.column("price", width=50)

            self.cosmetic_tree.heading("name", text="Name")
            self.cosmetic_tree.heading("type", text="Type")
            self.cosmetic_tree.heading("price", text="Price")

            self.show_cosmetic_from_admin_on_tree_view()

#===========Adding_Scroll_Bar========================================================================================
#====================================================================================================================
            self.cosmetic_tree_scroll = ttk.Scrollbar(self.window_cosmetic, orient="vertical", command=self.cosmetic_tree.yview)
            self.cosmetic_tree.configure(yscroll=self.cosmetic_tree_scroll.set)
            self.cosmetic_tree_scroll.place(x=792, y=236, width=40, height=240)

#===========Tree_View_In_Cosmetic_Store_Where_Customer_Add_To_Cart_To_Bought==========================================
#=====================================================================================================================
            self.cosmetic_cart = ttk.Treeview(self.window_cosmetic, columns=("name", "type", "quantity", "price"))
            self.cosmetic_cart.place(x=42, y=527, width=752, height=240)
            self.cosmetic_cart['show'] = 'headings'
            self.cosmetic_cart.column("name", width=175)
            self.cosmetic_cart.column("type", width=25)
            self.cosmetic_cart.column("quantity", width=50)
            self.cosmetic_cart.column("price", width=50)

            self.cosmetic_cart.heading("name", text="Name")
            self.cosmetic_cart.heading("type", text="Type")
            self.cosmetic_cart.heading("quantity", text="Quantity")
            self.cosmetic_cart.heading("price", text="Price")

            self.show_cosmetic_cart_tree()

#===========Adding_Scroll_Bar=========================================================================================
#=====================================================================================================================
            self.cosmetic_cartscroll = ttk.Scrollbar(self.window_cosmetic,orient="vertical",command=self.cosmetic_cart.yview)
            self.cosmetic_cart.configure(yscroll=self.cosmetic_cartscroll.set)
            self.cosmetic_cartscroll.place(x=795,y=528,width=40,height=240)

#==Importing_Cosmetic_Added_By_Admin==================================================================================
#=====================================================================================================================
    def show_cosmetic_from_admin_on_tree_view(self):
        self.cosmetic_tree.delete(*self.cosmetic_tree.get_children())
        data = self.info_food.show_cosmetic()
        for i in data:
            self.cosmetic_tree.insert("", "end", text=i[0], value=(i[1], i[2], i[3]))
            self.cosmetic_tree.bind("<Double-1>", self.on_cosmetic_select_on_cosmetic_tree_view_where_admin_foods_displayed)



#===Making_Functions_To_Update_Cosmetic_From_Admin_Tree_Root_To_Display_In_Entries====================================
#=====================================================================================================================
    def on_cosmetic_select_on_cosmetic_tree_view_where_admin_foods_displayed(self, event):
        selected_row = self.cosmetic_tree.selection()[0]
        selected_item = self.cosmetic_tree.item(selected_row, 'values')
        self.update_index = self.cosmetic_tree.item(selected_row, 'text')
        print(selected_item)
        self.name_entry.delete(0, END)
        self.name_entry.insert(0, selected_item[0])

        self.types_entry.delete(0, END)
        self.types_entry.insert(0, selected_item[1])

        self.price_entry.delete(0, END)
        self.price_entry.insert(0, selected_item[2])
        #self.show_cosmetic_from_admin_on_tree_view()



#==To_Import_Cosmetic_On_Cart_Tree=======================================================================================
#=====================================================================================================================

    def show_cosmetic_cart_tree(self):
        self.cosmetic_cart.delete(*self.cosmetic_cart.get_children())
        data = self.info_food.show_cart()
        for i in data:
            self.cosmetic_cart.insert("", "end", text=i[0], value=i)
            self.cosmetic_cart.bind("<Double-1>", self.on_cosmetic_select)

#==To_Display_Cosmetic_On_Entries_When_Product_Is_Doubled_Clicked=====================================================
#=====================================================================================================================
    def on_cosmetic_select(self,event):
        selected_row = self.cosmetic_cart.selection()[0]
        global update_index
        update_index = (self.cosmetic_cart.index(selected_row))
        all_item = self.info_food.show_cart()
        selected_item = all_item[update_index]
        print(selected_item)

        self.name_entry.delete(0,END)
        self.name_entry.insert(0,selected_item[0])

        self.types_entry.delete(0,END)
        self.types_entry.insert(0,selected_item[1])

        self.quantity_entry.delete(0,END)
        self.quantity_entry.insert(0,selected_item[2])

        self.price_entry.delete(0,END)
        self.price_entry.insert(0,selected_item[3])


#===To_Update_Cosmetic_On_Cart_Tree======================================================================================
#=====================================================================================================================
    def update_cosmetics(self):
        global update_index
        if update_index == "":
            messagebox.showerror("Error","please select the cart items first")


        else:
            name = self.name_entry.get()
            types = self.types_entry.get()
            quantity = self.quantity_entry.get()
            rate = self.price_entry.get()
            username = self.customer_Name_Entry.get()

            global total

            try:
                q = float(self.quantity_entry.get())
                p = float(self.price_entry.get())

                total = q * p
            except ValueError:
                messagebox.showerror("Error","quantity or price can't be strings")
                self.quantity_entry.delete(0,END)
                return True

            if self.name_entry.get() == "" or self.types_entry.get() == "" or self.quantity_entry.get() == "" or self.price_entry.get() == "":
                messagebox.showerror("Error", "All Entries Are Not Filled")
            else:
                name = self.name_entry.get()
                type = self.types_entry.get()
                quantity = self.quantity_entry.get()
                rate = self.price_entry.get()
                if self.info_food.update_cart(update_index,name,type,quantity,rate,total):
                    messagebox.showinfo("Info","Items Updated")
                    self.show_cosmetic_cart_tree()
                    update_index = ""

                self.name_entry.delete(0,END)
                self.types_entry.delete(0,END)
                self.quantity_entry.delete(0,END)
                self.price_entry.delete(0,END)

#===To_Add_Cosmetic_On_Cart_Tree======================================================================================
#=====================================================================================================================
    def cart_cosmetic(self):
        if self.name_entry.get() == "" or self.types_entry.get() == "" or self.quantity_entry.get() == "" or self.price_entry.get() == "":
            messagebox.showerror("Error", "All Entries Are Not Filled")
            pass
        else:
            name = self.name_entry.get()
            types = self.types_entry.get()
            quantity = self.quantity_entry.get()
            username = self.customer_Name_Entry.get()
            rate = self.price_entry.get()
            global total

            try:
                q = float(self.quantity_entry.get())
                p = float(self.price_entry.get())

                total = q * p
            except ValueError:
                messagebox.showerror("Error", "quantity or price can't be strings")
                self.quantity_entry.delete(0, END)
                return True
            if self.name_entry.get == "" or self.types_entry.get() == "" or self.quantity_entry.get() == "" or self.price_entry.get() == "":
                messagebox.showerror("Error", "All Entries Are Not Filled")
            elif self.info_food.cart_foods(name, types, quantity, username , rate, total):
                self.show_cosmetic_cart_tree()
                self.name_entry.delete(0, END)
                self.types_entry.delete(0, END)
                self.quantity_entry.delete(0, END)
                self.price_entry.delete(0, END)

    def remove_cosmetics(self):
        name = self.name_entry.get()
        type = self.types_entry.get()
        quantity = self.quantity_entry.get()
        rate = self.price_entry.get()
        selected_items = self.cosmetic_cart.selection()

        for selected_item in selected_items:
            self.cosmetic_cart.delete(selected_item)
            self.info_food.remove_selected_cart(name, type, quantity, rate)
            self.show_cosmetic_cart_tree()
            self.name_entry.delete(0, END)
            self.types_entry.delete(0, END)
            self.quantity_entry.delete(0, END)
            self.price_entry.delete(0, END)

    def search_cosmetics(self):
        name = self.search_entry.get()
        if self.search_entry.get() == "":
            messagebox.showerror("Error","Please fill give the item name to search!")
        else:
            self.cosmetic_tree.delete(*self.cosmetic_tree.get_children())
            data = self.info_food.Grocery_Cosmetics_Search(name)
            for i in data:
                self.cosmetic_tree.insert("", "end", text=i[0], value=(i[1], i[2], i[3]))
                self.cosmetic_tree.bind("<Double-1>", self.on_cosmetic_select_on_cosmetic_tree_view_where_admin_foods_displayed)

    def cosmetics_reset(self):
        self.search_entry.delete(0,END)
        self.show_cosmetic_from_admin_on_tree_view()


# =====================================================================================================================
# =====================================================================================================================
# ===============================================WINDOW_COSMETIC_END==================================================
# =====================================================================================================================
# =====================================================================================================================





#=====================================================================================================================
#=====================================================================================================================
#===============================================WINDOWS_COSMETIC_START===================================================
#=====================================================================================================================
#=====================================================================================================================

#===Making_Functions_For_Bill_For_Grocery_Windows_From_Cosmetic_Store====================================================
#=====================================================================================================================
    def Bill_For_bread(self):
        if self.name_entry.get() != "" or self.types_entry.get() != "" or self.quantity_entry.get() != "" or self.price_entry.get() != "":
            messagebox.showerror("error","PLease add first")


        elif len(self.bread_cart.get_children()) == 0:
            messagebox.showerror("Error","No items in the cart")
            return True
        else:
            name = self.name_entry.get()
            types = self.types_entry.get()
            quantity = self.quantity_entry.get()
            username = self.customer_Name_Entry.get()
            rate = self.price_entry.get()
            q = float(0)
            p = float(0)

            total = q * p
            print(total)

            if self.name_entry.get() != "" or self.types_entry.get() != "" or self.quantity_entry.get() != "" or self.price_entry.get() != "":
                messagebox.showerror("error", "PLease add first")


            elif len(self.bread_cart.get_children()) == 0:
                messagebox.showerror("Error", "No items in the cart")
                return True

            else:
                messagebox.showinfo("Congratulation", "Items Added To The Bill")
                self.show_Bill_From_bread_tree()
                self.window_bread.destroy()
                return True



#==Importing_From_List_Of_Items_Added_To_Cart_From_Cosmetic_Store_And_Putting_Them_In_Tree_View_Of_Grocery_Windows====
#=====================================================================================================================
    def show_Bill_From_bread_tree(self):
        data = self.info_food.show_cart()
        for i in data:
            self.grocery_tree.insert("", "end", text=i[0], value=i)

#===Making_New_Window_For_Cosmetic_Products==============================================================================
#=====================================================================================================================
    def bread_products(self):
        if self.customer_Name_Entry.get() == "" or self.customer_Id_Entry.get() == "" or self.customer_Number_Entry.get() == "":
            messagebox.showerror("Error","Please fill the customer details")
        else:
            from classes.Admin_infp import food_info
#=======For_Designing_Windows=========================================================================================
#=====================================================================================================================
            self.window_bread = Toplevel(self.grocery_window)
            self.info_food = food_info()
            self.window_bread.title("Foods Store")
            self.window_bread.geometry('1350x800')
            self.window_bread.resizable("false", "false")
            self.window_bread.grab_set()

#=======Designing_Label_Entries_Buttons===============================================================================
#=====================================================================================================================
            self.wn_back=PhotoImage(file="Bread_store.png")
            bg3 = Label(self.window_bread, image=self.wn_back).place(x=0, y=0, relwidth=1, relheight=1)

            self.name_label = Label(self.window_bread, text="Item Name",bg="white",font=("times new roman", 20, "bold"))
            self.name_label.place(x=130, y=115)

            self.name_entry = Entry(self.window_bread,bg="lightgray",font=("times new roman", 15, "bold"))
            self.name_entry.place(x=100, y=154)

            self.types_label = Label(self.window_bread,bg="white",text="Item Type", font=("times new roman", 20, "bold"))
            self.types_label.place(x=460, y=115)

            self.types_entry = Entry(self.window_bread,bg="lightgray",font=("times new roman", 15, "bold"))
            self.types_entry.place(x=420, y=154)

            self.quantity_label = Label(self.window_bread,bg="white",text="Item Quantity", font=("times new roman", 20, "bold"))
            self.quantity_label.place(x=750, y=115)

            self.quantity_entry = Entry(self.window_bread,bg="lightgray",font=("times new roman", 15, "bold"))
            self.quantity_entry.place(x=732, y=154)

            self.price_label = Label(self.window_bread, text="Item Price",bg="white",font=("times new roman", 20, "bold"))
            self.price_label.place(x=1075, y=115)

            self.price_entry = Entry(self.window_bread,bg="lightgray",font=("times new roman", 15, "bold"))
            self.price_entry.place(x=1036, y=154)

            self.search_entry = Entry(self.window_bread, bg="lightgray", font=("times new roman", 15, "bold"))
            self.search_entry.place(x=895, y=380)

            self.search_img = PhotoImage(file="search.png")
            self.search_Button = Button(self.window_bread, image=self.search_img, bg="white", borderwidth=0,font=("times new roman", 15, "bold"),command=self.search_breads)
            self.search_Button.place(x=1150, y=350, width=80, height=70)

            self.search_reset = Button(self.window_bread, text="R e s e t", bg="white", borderwidth=0,font=("times new roman", 12, "bold"),command=self.bread_reset)
            self.search_reset.place(x=1225, y=320)

            self.bread_update_img = PhotoImage(file="Foods_Update.png")
            self.Update_bread = Button(self.window_bread,borderwidth=0,image=self.bread_update_img,command=self.update_breads)
            self.Update_bread.place(x=848, y=590, width=475, height=50)

            self.cart_img = PhotoImage(file="cart.png")
            self.add_cart = Button(self.window_bread,image=self.cart_img,borderwidth=0,command=self.cart_bread)
            self.add_cart.place(x=850, y=650, width=140, height=120)

            self.delete_cart_img = PhotoImage(file="delete_cart.png")
            self.cart_delete = Button(self.window_bread,borderwidth=0,image=self.delete_cart_img,command=self.remove_breads)
            self.cart_delete.place(x=1016, y=650, width=140, height=120)

            self.Bill_img = PhotoImage(file="Bill.png")
            self.generate_Bill_For_Grocery = Button(self.window_bread,image=self.Bill_img,borderwidth=0,command=self.Bill_For_bread)
            self.generate_Bill_For_Grocery.place(x=1178, y=650, width=140, height=120)

#==========Tree_View_In_Cosmetic_Store_Which_Contains_Items_Added_From_Admin_Stores===================================
#=====================================================================================================================
            self.bread_tree = ttk.Treeview(self.window_bread, columns=("name", "type", "price"))
            self.bread_tree.place(x=38, y=235, width=752, height=240)
            self.bread_tree['show'] = 'headings'
            self.bread_tree.column("name", width=200)
            self.bread_tree.column("type", width=100)
            self.bread_tree.column("price", width=50)

            self.bread_tree.heading("name", text="Name")
            self.bread_tree.heading("type", text="Type")
            self.bread_tree.heading("price", text="Price")

            self.show_bread_from_admin_on_tree_view()


#===========Adding_Scroll_Bar========================================================================================
#====================================================================================================================
            self.bread_tree_scroll = ttk.Scrollbar(self.window_bread, orient="vertical", command=self.bread_tree.yview)
            self.bread_tree.configure(yscroll=self.bread_tree_scroll.set)
            self.bread_tree_scroll.place(x=792, y=236, width=40, height=240)

#===========Tree_View_In_Cosmetic_Store_Where_Customer_Add_To_Cart_To_Bought==========================================
#=====================================================================================================================
            self.bread_cart = ttk.Treeview(self.window_bread, columns=("name", "type", "quantity", "price"))
            self.bread_cart.place(x=42, y=527, width=752, height=240)
            self.bread_cart['show'] = 'headings'
            self.bread_cart.column("name", width=175)
            self.bread_cart.column("type", width=25)
            self.bread_cart.column("quantity", width=50)
            self.bread_cart.column("price", width=50)

            self.bread_cart.heading("name", text="Name")
            self.bread_cart.heading("type", text="Type")
            self.bread_cart.heading("quantity", text="Quantity")
            self.bread_cart.heading("price", text="Price")

            self.show_bread_cart_tree()

#===========Adding_Scroll_Bar=========================================================================================
#=====================================================================================================================
            self.bread_cartscroll = ttk.Scrollbar(self.window_bread,orient="vertical",command=self.bread_cart.yview)
            self.bread_cart.configure(yscroll=self.bread_cartscroll.set)
            self.bread_cartscroll.place(x=795,y=528,width=40,height=240)

#==Importing_Cosmetic_Added_By_Admin==================================================================================
#=====================================================================================================================
    def show_bread_from_admin_on_tree_view(self):
        self.bread_tree.delete(*self.bread_tree.get_children())
        data = self.info_food.show_bread()
        print(data)
        for i in data:
            self.bread_tree.insert("", "end", text=i[0], value=(i[1], i[2], i[3]))
            self.bread_tree.bind("<Double-1>", self.on_bread_select_on_bread_tree_view_where_admin_foods_displayed)

#===Making_Functions_To_Update_Cosmetic_From_Admin_Tree_Root_To_Display_In_Entries====================================
#=====================================================================================================================
    def on_bread_select_on_bread_tree_view_where_admin_foods_displayed(self, event):
        selected_row = self.bread_tree.selection()[0]
        selected_item = self.bread_tree.item(selected_row, 'values')
        self.update_index = self.bread_tree.item(selected_row, 'text')
        print(selected_item)
        self.name_entry.delete(0, END)
        self.name_entry.insert(0, selected_item[0])

        self.types_entry.delete(0, END)
        self.types_entry.insert(0, selected_item[1])

        self.price_entry.delete(0, END)
        self.price_entry.insert(0, selected_item[2])
        #self.show_bread_from_admin_on_tree_view()


#==To_Import_Cosmetic_On_Cart_Tree=======================================================================================
#=====================================================================================================================
    def show_bread_cart_tree(self):
        self.bread_cart.delete(*self.bread_cart.get_children())
        data = self.info_food.show_cart()
        for i in data:
            self.bread_cart.insert("", "end", text=i[0], value=i)
            self.bread_cart.bind("<Double-1>", self.on_bread_select)

#==To_Display_Cosmetic_On_Entries_When_Product_Is_Doubled_Clicked=====================================================
#=====================================================================================================================
    def on_bread_select(self,event):
        selected_row = self.bread_cart.selection()[0]
        global update_index
        update_index = (self.bread_cart.index(selected_row))
        all_item = self.info_food.show_cart()
        selected_item = all_item[update_index]
        print(selected_item)

        self.name_entry.delete(0,END)
        self.name_entry.insert(0,selected_item[0])

        self.types_entry.delete(0,END)
        self.types_entry.insert(0,selected_item[1])

        self.quantity_entry.delete(0,END)
        self.quantity_entry.insert(0,selected_item[2])

        self.price_entry.delete(0,END)
        self.price_entry.insert(0,selected_item[3])


#===To_Update_Cosmetic_On_Cart_Tree======================================================================================
#=====================================================================================================================

    def update_breads(self):
        global update_index
        if update_index == "":
            messagebox.showerror("Error","please select the cart items first")


        else:
            name = self.name_entry.get()
            types = self.types_entry.get()
            quantity = self.quantity_entry.get()
            rate = self.price_entry.get()
            username = self.customer_Name_Entry.get()

            global total

            try:
                q = float(self.quantity_entry.get())
                p = float(self.price_entry.get())

                total = q * p
            except ValueError:
                messagebox.showerror("Error","quantity or price can't be strings")
                self.quantity_entry.delete(0,END)
                return True

            if self.name_entry.get() == "" or self.types_entry.get() == "" or self.quantity_entry.get() == "" or self.price_entry.get() == "":
                messagebox.showerror("Error", "All Entries Are Not Filled")
            else:
                name = self.name_entry.get()
                type = self.types_entry.get()
                quantity = self.quantity_entry.get()
                rate = self.price_entry.get()
                if self.info_food.update_cart(update_index,name,type,quantity,rate,total):
                    messagebox.showinfo("Info","Items Updated")
                    self.show_bread_cart_tree()
                    update_index = ""

                self.name_entry.delete(0,END)
                self.types_entry.delete(0,END)
                self.quantity_entry.delete(0,END)
                self.price_entry.delete(0,END)

#===To_Add_Cosmetic_On_Cart_Tree======================================================================================
#=====================================================================================================================
    def cart_bread(self):
        if self.name_entry.get() == "" or self.types_entry.get() == "" or self.quantity_entry.get() == "" or self.price_entry.get() == "":
            messagebox.showerror("Error", "All Entries Are Not Filled")
            pass
        else:
            name = self.name_entry.get()
            types = self.types_entry.get()
            quantity = self.quantity_entry.get()
            username = self.customer_Name_Entry.get()
            rate = self.price_entry.get()
            global total

            try:
                q = float(self.quantity_entry.get())
                p = float(self.price_entry.get())

                total = q * p
            except ValueError:
                messagebox.showerror("Error", "quantity or price can't be strings")
                self.quantity_entry.delete(0, END)
                return True
            if self.name_entry.get == "" or self.types_entry.get() == "" or self.quantity_entry.get() == "" or self.price_entry.get() == "":
                messagebox.showerror("Error", "All Entries Are Not Filled")
            elif self.info_food.cart_foods(name, types, quantity, username ,rate,total):
                self.show_bread_cart_tree()
                self.name_entry.delete(0, END)
                self.types_entry.delete(0, END)
                self.quantity_entry.delete(0, END)
                self.price_entry.delete(0, END)


    def remove_breads(self):
        name = self.name_entry.get()
        type = self.types_entry.get()
        quantity = self.quantity_entry.get()
        rate = self.price_entry.get()
        selected_items = self.bread_cart.selection()

        for selected_item in selected_items:
            self.bread_cart.delete(selected_item)
            self.info_food.remove_selected_cart(name, type, quantity, rate)
            self.show_bread_cart_tree()
            self.name_entry.delete(0, END)
            self.types_entry.delete(0, END)
            self.quantity_entry.delete(0, END)
            self.price_entry.delete(0, END)

    def search_breads(self):
        name = self.search_entry.get()
        if self.search_entry.get() == "":
            messagebox.showerror("Error","Please fill give the item name to search!")
        else:
            self.bread_tree.delete(*self.bread_tree.get_children())
            data = self.info_food.Grocery_Breads_Search(name)
            for i in data:
                self.bread_tree.insert("", "end", text=i[0], value=(i[1], i[2], i[3]))
                self.bread_tree.bind("<Double-1>", self.on_bread_select_on_bread_tree_view_where_admin_foods_displayed)

    def bread_reset(self):
        self.search_entry.delete(0,END)
        self.show_bread_from_admin_on_tree_view()


# =====================================================================================================================
# =====================================================================================================================
# ===============================================WINDOW_COSMETIC_END==================================================
# =====================================================================================================================
# =====================================================================================================================


    def ll(self):
        a=float(self.customer_Number_Entry.get())
        b=float(self.customer_Number_Entry.get())
        tot = a * b
        print(tot)




def main():
    grocery_window = Tk()
    obj = Grocery_System(grocery_window)
    grocery_window.mainloop()
if __name__ == '__main__':
    main()
