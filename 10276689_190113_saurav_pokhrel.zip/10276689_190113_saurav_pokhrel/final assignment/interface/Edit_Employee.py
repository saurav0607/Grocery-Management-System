from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox
global update_index
from classes.Admin_infp import food_info
import datetime


class employee:
    def __init__(self, employee_window):
        # =======For_Designing_Windows=========================================================================================
        # =====================================================================================================================
        self.employee_window = employee_window
        self.employee_window.title("Change Password")
        self.employee_window.geometry('950x700+0+0')
        self.employee_window.resizable("false", "false")
        self.employee_window.grab_set()

        self.info_food = food_info()

        def time():
            now = datetime.datetime.now()
            self.date = (now.strftime("%I:%M:%S:%p"))
            self.daa = (now.strftime("%H:%M:%S '/n' %d-%m-%y"))
            self.clock_label = Label(self.employee_window, font=('times new roman', 18), fg='black', bg="White",
                                     text=self.date)
            self.clock_label.place(x=750, y=30)
            self.clock_label.after(200, time)

        time()

        self.bg2 = ImageTk.PhotoImage(file="C:\\Users\\DELL\\Desktop\\python_projects\\edit_employee.jpg")
        bg = Label(self.employee_window, image=self.bg2)
        bg.place(x=0, y=0, relwidth=1, relheight=1)

        self.name = Label(self.employee_window, text="Full Name", bg="white", fg="green", font=("times new roman", 20, "bold"))
        self.name.place(x=50, y=120, width=250)

        self.name_entry = Entry(self.employee_window, font=("times nfdew roman", 15), highlightbackground='black', highlightthickness="2")
        self.name_entry.place(x=50, y=165, width=250)

        self.phone = Label(self.employee_window, text="Phone No", bg="white", fg="green", font=("times new roman", 20, "bold"))
        self.phone.place(x=360, y=120, width=250)

        self.phone_entry = Entry(self.employee_window, font=("times new roman", 15), highlightbackground='black',highlightthickness="2")
        self.phone_entry.place(x=360, y=165, width=250)

        self.gender = Label(self.employee_window, text="Gender", bg="white", fg="green", font=("times new roman", 20, "bold"))
        self.gender.place(x=40, y=220, width=250)

        self.combo_box_gender = ttk.Combobox(self.employee_window, font=("times new roman", 15), state="readonly",justify=CENTER)
        self.combo_box_gender.place(x=46, y=260, width=250, height=30)
        self.combo_box_gender["values"] = ("Select", "Male", "Female")

        self.adress = Label(self.employee_window, text="Address", bg="white", fg="green", font=("times new roman", 20, "bold"))
        self.adress.place(x=354, y=220, width=250)

        self.adress_entry = Entry(self.employee_window, font=("times new roman", 15), highlightbackground='black', highlightthickness="2")
        self.adress_entry.place(x=356, y=260, width=250)

        self.password = Label(self.employee_window, text="Password", bg="white", fg="green", font=("times new roman", 20, "bold"))
        self.password.place(x=660, y=220, width=250)

        self.password_entry = Entry(self.employee_window, font=("times new roman", 15), show="*", fg="red",highlightbackground='black', highlightthickness="2")
        self.password_entry.place(x=654, y=260, width=250)

        self.img_update = PhotoImage(file="pass_update.png")
        self.update = Button(self.employee_window, image=self.img_update, borderwidth=0,command=self.update_informations)
        self.update.place(x=600, y=605, height=60, width=70)

        self.img_del = PhotoImage(file="emplo_delete.png")
        self.update = Button(self.employee_window, image=self.img_del, borderwidth=0,command=self.delete_cosmetics)
        self.update.place(x=760, y=600, height=70, width=60)

        self.res_img = PhotoImage(file="passwod_reset.png")
        self.reset = Button(self.employee_window, image=self.res_img, borderwidth=0,command=self.on_reset)
        self.reset.place(x=460, y=610, height=50, width=60)

        self.employee_tree = ttk.Treeview(self.employee_window, columns=("name", "phone","gender","address","password"))
        self.employee_tree.place(x=50, y=300, width=820, height=300)
        self.employee_tree['show'] = 'headings'
        self.employee_tree.column("name", width=100)
        self.employee_tree.column("phone", width=100)
        #self.employee_tree.column("..", width=50)
        self.employee_tree.column("gender", width=50)
        self.employee_tree.column("address", width=50)
        self.employee_tree.column("password", width=50)

        self.employee_tree.heading("name", text="Name")
        self.employee_tree.heading("phone", text="Phone")
        #self.employee_tree.heading("..", text="..")
        self.employee_tree.heading("gender", text="Gender")
        self.employee_tree.heading("address", text="Address")
        self.employee_tree.heading("password", text="Password")

        self.update_index = ""

        self.show_employee_info()

        self.employee_tree_scroll = ttk.Scrollbar(self.employee_window, orient="vertical", command=self.employee_tree.yview)
        self.employee_tree.configure(yscroll=self.employee_tree_scroll.set)
        self.employee_tree_scroll.place(x=874, y=300, width=40, height=300)

    def show_employee_info(self):
        self.employee_tree.delete(*self.employee_tree.get_children())
        data = self.info_food.show_employee()
        for i in data:
            self.employee_tree.insert("", "end", text=i[0], value=(i[1],i[2],i[3],i[4],i[5]))
            self.employee_tree.bind("<Double-1>", self.on_employee_tree_select)

    def on_employee_tree_select(self, event):
        selected_row = self.employee_tree.selection()[0]
        selected_item = self.employee_tree.item(selected_row, 'values')
        self.update_index = self.employee_tree.item(selected_row, 'text')
        print(selected_item)
        self.name_entry.delete(0, END)
        self.name_entry.insert(0, selected_item[0])

        self.phone_entry.delete(0, END)
        self.phone_entry.insert(0, selected_item[1])

        self.adress_entry.delete(0, END)
        self.adress_entry.insert(0, selected_item[3])

        self.combo_box_gender.set(selected_item[2])
        self.combo_box_gender.current()

        self.password_entry.delete(0, END)
        self.password_entry.insert(0, selected_item[4])

    def empty_exception(self):
        if self.name_entry.get() == "" or self.phone_entry.get() == "" or self.adress_entry.get() == "" or self.password_entry.get() == "":
            messagebox.showerror("Error", "Entries are empty!!!")
            return True
            pass

    def update_informations(self):
        global update_index

        if self.update_index == "":
            messagebox.showerror("Error", "please select the foods item first")

        elif self.empty_exception():
            return True

        else:
            name = self.name_entry.get()
            phone = self.phone_entry.get()
            age = self.combo_box_gender.get()
            address = self.adress_entry.get()
            password = self.password_entry.get()


            if self.info_food.update_employee(self.update_index, name, phone, age, address, password):
                messagebox.showinfo("Item", "updated")

                self.on_reset()

                self.show_employee_info()
                self.update_index = ""
            else:
                messagebox.showerror("Error", "cannot be updated!!!!")

    def delete_cosmetics(self):
        global update_index

        if len(self.employee_tree.get_children()) == 0:
            messagebox.showerror("Error", "Can't be deleted because nothing is in the cart")

        elif self.update_index == "":
            messagebox.showerror("Error", "please select the employee first")

        else:
            name = self.name_entry.get()
            phone = self.phone_entry.get()
            address = self.adress_entry.get()
            password = self.password_entry.get()


            if self.info_food.delete_employee(name, phone, address, password):
                messagebox.showinfo("Item", "employee deleted")
                self.on_reset()

                self.show_employee_info()
                self.update_index = ""

            else:
                messagebox.showerror("Error", "cannot be deleted!!!!")

    def on_reset(self):
        self.name_entry.delete(0,END)
        self.phone_entry.delete(0, END)
        self.adress_entry.delete(0, END)
        self.password_entry.delete(0, END)
        self.combo_box_gender.set("")
        self.show_employee_info()



        #self.user_name_label = Label(self.employee_window, text="Username", bg="white", font=("times new roman", 15, "bold"))
        #self.user_name_label.place(x=65, y=20)

        #self.user_name_entry = Entry(self.employee_window, highlightbackground='black', highlightthickness="1",font=("times new roman", 11, "bold"))
        #self.user_name_entry.place(x=26, y=60)

        #self.user_password_label = Label(self.employee_window, text="Password", bg="white",font=("times new roman", 15, "bold"))
        #self.user_password_label.place(x=260, y=20)

        #self.user_password_entry = Entry(self.employee_window, highlightbackground='black', highlightthickness="1",font=("times new roman", 11, "bold"))
        #self.user_password_entry.place(x=220, y=60)

        #self.pasword_res_img = PhotoImage(file="passwod_reset.png")
        #self.reset = Button(self.employee_window, image=self.pasword_res_img, borderwidth=0)
        #self.reset.place(x=400, y=40, height=50, width=60)
        #self.employee_window.grab_set()

        #self.img_add = PhotoImage(file="pass_add.png")
        #self.add = Button(self.employee_window, image=self.img_add, borderwidth=0)
        #self.add.place(x=80, y=356, height=60, width=70)



        #self.update_index = ""

        #self.password_tree = ttk.Treeview(self.employee_window, columns=('username', 'password'))
        #self.password_tree.place(x=24, y=110, width=460, height=240)
        #self.password_tree['show'] = 'headings'
        #self.password_tree.column('username', width=150)
        #self.password_tree.column('password', width=100)

        #self.password_tree.heading('username', text="User Name")
        #self.password_tree.heading('password', text="Password")


        # =======Adding_Scroll_Bar=============================================================================================
        # =====================================================================================================================
        #self.password_tree_scroll = ttk.Scrollbar(self.employee_window, orient="vertical",command=self.password_tree.yview)
        #self.password_tree.configure(yscroll=self.password_tree_scroll.set)
        #self.password_tree_scroll.place(x=486, y=112, width=40, height=236)


def main():
    grocery_window = Tk()
    obj = employee(grocery_window)
    grocery_window.mainloop()
if __name__ == '__main__':
    main()

