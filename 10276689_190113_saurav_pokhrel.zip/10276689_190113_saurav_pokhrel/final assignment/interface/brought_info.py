from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from tkinter import messagebox
global update_index
from classes.Admin_infp import food_info
import datetime


class customer:
    def __init__(self, customer_window):
        # =======For_Designing_Windows=========================================================================================
        # =====================================================================================================================
        self.customer_window = customer_window
        self.customer_window.title("Change Password")
        self.customer_window.geometry('950x700')
        self.customer_window.resizable("false", "false")

        self.info_food = food_info()

        def time():
            now = datetime.datetime.now()
            self.date = (now.strftime("%I:%M:%S:%p"))
            self.daa = (now.strftime("%H:%M:%S '/n' %d-%m-%y"))
            self.clock_label = Label(self.customer_window, font=('times new roman', 18), fg='black', bg="White",text=self.date)
            self.clock_label.place(x=750, y=30)
            self.clock_label.after(200, time)

        time()

        self.bg2 = ImageTk.PhotoImage(file="C:\\Users\\DELL\\Desktop\\python_projects\\customer.jpg")
        bg = Label(self.customer_window, image=self.bg2)
        bg.place(x=0, y=0, relwidth=1, relheight=1)

        self.name = Label(self.customer_window, text="User Name", bg="white", fg="green", font=("times new roman", 15, "bold"))
        self.name.place(x=100, y=150, width=100)

        self.name_entry = Entry(self.customer_window, font=("times nfdew roman", 15), highlightbackground='black', highlightthickness="2")
        self.name_entry.place(x=75, y=180, width=150,height=30)

        self.img_del = PhotoImage(file="emplo_delete.png")
        self.update = Button(self.customer_window, image=self.img_del, borderwidth=0)
        self.update.place(x=760, y=600, height=70, width=60)

        self.res_img = PhotoImage(file="passwod_reset.png")
        self.reset = Button(self.customer_window, image=self.res_img, borderwidth=0)
        self.reset.place(x=460, y=610, height=50, width=60)

        self.employee_tree = ttk.Treeview(self.customer_window, columns=("name", "phone","gender","address","password"))
        self.employee_tree.place(x=50, y=300, width=820, height=300)
        self.employee_tree['show'] = 'headings'
        self.employee_tree.column("name", width=100)
        self.employee_tree.column("phone", width=100)
        #self.employee_tree.column("..", width=50)
        self.employee_tree.column("gender", width=50)
        self.employee_tree.column("address", width=50)
        self.employee_tree.column("password", width=50)

        self.employee_tree.heading("name", text="Name")
        self.employee_tree.heading("phone", text="Phone")
        #self.employee_tree.heading("..", text="..")
        self.employee_tree.heading("gender", text="Gender")
        self.employee_tree.heading("address", text="Address")
        self.employee_tree.heading("password", text="Password")

        self.update_index = ""

        self.employee_tree_scroll = ttk.Scrollbar(self.customer_window, orient="vertical", command=self.employee_tree.yview)
        self.employee_tree.configure(yscroll=self.employee_tree_scroll.set)
        self.employee_tree_scroll.place(x=874, y=300, width=40, height=300)

def main():
    grocery_window = Tk()
    obj = customer(grocery_window)
    grocery_window.mainloop()
if __name__ == '__main__':
    main()

