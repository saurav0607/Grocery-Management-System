from tkinter import *                                 
from classes.register_info import Info
from interface.login_ import Sign
from classes.Admin_infp import food_info
from PIL import Image,ImageTk
from tkinter import ttk
from tkinter import messagebox
import datetime
class SignUp:      
    def __init__(self,window):
#=======Creating_Geometry============================================================================================
#====================================================================================================================
        self.window = window
        self.window.title("User Registration")
        self.window.geometry('1150x700+0+0')
        self.window.resizable("false","false")


        def time():
            now = datetime.datetime.now()
            self.date = (now.strftime("%I:%M:%S:%p"))
            self.daa = (now.strftime("%H:%M:%S '/n' %d-%m-%y"))
            self.clock_label = Label(self.window, font=('times new roman', 12), fg='black', bg="White",text=self.date)
            self.clock_label.place(x=1010, y=115)
            self.clock_label.after(200, time)
        time()

#=======Importing_Class_Of_Register_Info=============================================================================
#====================================================================================================================
        self.info = Info()

#=======Adding_Bg_Image==============================================================================================
#====================================================================================================================
        self.bg2 = ImageTk.PhotoImage(file="C:\\Users\\DELL\\Desktop\\python_projects\\user_registration.jpg")
        bg = Label(self.window,bg="black",image=self.bg2).place(x=0,y=0,relwidth=1,relheight=1)

#=======Left_Image===================================================================================================
#====================================================================================================================
        self.left = ImageTk.PhotoImage(file="C:\\Users\\DELL\\Desktop\\python_projects\\frame1.jpg")
        # left = Label(self.window,image=self.left,bg="white").place(x=20,y=100,width=400,height=500)

        self.lbl = Label(self.window,image=self.left)
        self.lbl.place(x=420,y=100,width=700,height=500)


#=======Frame_1======================================================================================================
#====================================================================================================================
        # self.self.lbl=Frame(self.window,bg="white")
        # self.self.lbl.place(x=420,y=100,width=700,height=500)

#=======For_Reset_Button==============================================================================================
#====================================================================================================================
        self.Name = StringVar()
        self.Phone = StringVar()
        self.Email = StringVar()
        self.Adress = StringVar()
        self.Password = StringVar()
        self.Repassword = StringVar()

#=======Label_And_Entry_For_Registration==============================================================================
#===================================================================================================================
        # self.name = Label(self.lbl,text="Full Name",bg="white",fg="green",font=("times new roman",20,"bold"))
        # self.name.place(x=0,y=8,width=250)

        self.name_entry = Entry(self.lbl,font=("times nfdew roman",15),bg="White",highlightbackground='black',highlightthickness="1",textvariable=self.Name)
        self.name_entry.place(x=10,y=50,width=250)

        # self.phone = Label(self.lbl, text="Phone No", bg="white", fg="green", font=("times new roman", 20, "bold"))
        # self.phone.place(x=350, y=8,width=250)

        self.phone_entry = Entry(self.lbl, font=("times new roman", 15), bg="White",highlightbackground='black',highlightthickness="1",textvariable=self.Phone)
        self.phone_entry.place(x=350, y=50,width=250)
        #
        # self.email = Label(self.lbl, text="Email", bg="white", fg="green", font=("times new roman", 20, "bold"))
        # self.email.place(x=0, y=90,width=250)

        self.email_entry = Entry(self.lbl, font=("times new roman", 15), bg="White",highlightbackground='black',highlightthickness="1",textvariable=self.Email)
        self.email_entry.place(x=10, y=130,width=250)

        # self.gender = Label(self.lbl, text="Gender", bg="white", fg="green", font=("times new roman", 20, "bold"))
        # self.gender.place(x=335, y=88, width=250)

        self.combo_box_gender = ttk.Combobox(self.lbl,font=("times new roman", 15),state="readonly",justify=CENTER)
        self.combo_box_gender.place(x=350,y=130,width=250,height=30)
        self.combo_box_gender["values"] = ("Select","Male","Female")

        # self.adress = Label(self.lbl, text="Address", bg="white", fg="green", font=("times new roman", 20, "bold"))
        # self.adress.place(x=0,y=170,width=250)

        self.adress_entry = Entry(self.lbl, font=("times new roman", 15), bg="White",highlightbackground='black',highlightthickness="1",textvariable=self.Adress)
        self.adress_entry.place(x=10,y=210,width=250)

        # self.password = Label(self.lbl, text="Password", bg="white", fg="green", font=("times new roman", 20, "bold"))
        # self.password.place(x=350,y=172,width=250)

        self.password_entry = Entry(self.lbl, font=("times new roman", 15), bg="White",show="*",fg="red",highlightbackground='black',highlightthickness="1",textvariable=self.Password)
        self.password_entry.place(x=350, y=210, width=250)

        # self.re_password = Label(self.lbl, text="Re Enter Password", bg="white", fg="green",font=("times new roman", 20, "bold"))
        # self.re_password.place(x=0, y=250, width=250)

        self.re_password_entry = Entry(self.lbl, font=("times new roman", 15), bg="White",show="*",fg="red",highlightbackground='black',highlightthickness="1",textvariable=self.Repassword)
        self.re_password_entry.place(x=6, y=290, width=250)

#=======Buttons=======================================================================================================
#====================================================================================================================
        self.bttn_signin = Button(self.window,text="S i g n   I n",cursor="hand2",fg="Red",bg="White",borderwidth=0,font=("times new roman",12),command=self.sign_in)
        self.bttn_signin.place(x=540,y=565)

        self.bttn_reset = Button(self.lbl,activeforeground="Red",activebackground="White", text="R    e    s    e    t",cursor="hand2",borderwidth=0,bg="White", font=("times new roman", 15),command=self.reset)
        self.bttn_reset.place(x=350, y=280,width=250)

        self.bttn_register = Button(self.lbl,activeforeground="Red",activebackground="White", text="R  e  g  i  s  t  e  r",cursor="hand2",bg="White",borderwidth=0,font=("times new roman", 15,"bold"),command=self.Register)
        self.bttn_register.place(x=380, y=450, width=300)

        self.lb2 = Label(self.window,text="A  l  r  e  a  d  y    h  a  v  e    a  c  c  o  u  n  t ?",font=("times new roman",9),bg="White")
        self.lb2.place(x=460,y=546)

        # self.bttn_exit = Button(self.lbl, text="Exit", font=("times new roman", 15),bg="red",command=self.window.quit)
        # self.bttn_exit.place(x=590, y=460, width=100)

#=======For_Check_Buttons=============================================================================================
#====================================================================================================================
        self.variable2 = IntVar()
        self.check_button = Checkbutton(self.lbl,text="I Agree The Terms & Conditions",font=("times new roman",15,"bold"),variable=self.variable2,onvalue=1,offvalue=0,bg="white")
        self.check_button.place(x=260,y=370)
#===DIFFERENT FUNCTIONS===============================================================================================
#===Reset=============================================================================================================
#=====================================================================================================================
#====================================================================================================================
    def reset(self):
        self.Name.set('')
        self.Phone.set('')
        self.Email.set('')
        self.Adress.set('')
        self.Password.set('')
        self.Repassword.set('')
        self.combo_box_gender.set('')


#===Sign_In_Window====================================================================================================
#=====================================================================================================================
    def sign_in(self):
#=======To_Close_Previous_Window======================================================================================
#====================================================================================================================
        self.window.withdraw()
#=======T0_Open_Login_Window==========================================================================================
#====================================================================================================================
        self.top = Toplevel(self.window)
        Sign(self.top)

    def Register(self):
        nam = self.name_entry.get()
        pas = self.password_entry.get()
#======To_Create_Different_Exceptions=================================================================================
#====================================================================================================================
        def exception():
            try:
                self.string_answer = self.phone_entry.get()
                self.int_answer = int(self.string_answer)
                self.count = len(self.string_answer)
                if self.count != int(10):
                    messagebox.showerror("Error","Phone numbers must be equals to 10!")
                    return TRUE
            except ValueError:
                messagebox.showerror("Error","phone number can't includes string values!")
                return TRUE

#=======Psswd=["/","!","_"]===========================================================================================
#====================================================================================================================
        if self.name_entry.get() == "" or self.phone_entry.get() == "" or self.adress_entry.get() == "" or self.password_entry.get() == "" or self.re_password_entry.get() == "":
            messagebox.showerror("Error","please fill all the entries!")

        elif self.password_entry.get() != self.re_password_entry.get():
            messagebox.showerror("Error","your password did not match!")

        elif exception():
            return TRUE

        elif self.variable2.get() == 0:
            messagebox.showerror("Error","Please Accept Terms & Conditions!")

        else:
            name = self.name_entry.get()
            phone = self.phone_entry.get()
            address = self.adress_entry.get()
            password = self.password_entry.get()
            cmbo_box = self.combo_box_gender.get()
            username = self.email_entry.get()

            if self.info.find_user(username):
                print("ooooo")

            elif self.info.Register(name, phone, cmbo_box, address, password,username):
                messagebox.showinfo("Congratulation","Registration Successfull !")

#===============To_Delete_Entries_Fill_After_Register_Button_Is_Clicked===============================================
#=====================================================================================================================
                self.name_entry.delete(0,END)
                self.phone_entry.delete(0,END)
                self.email_entry.delete(0,END)
                self.adress_entry.delete(0,END)
                self.password_entry.delete(0,END)
                self.re_password_entry.delete(0,END)


