from tkinter import *
from classes.Admin_infp import food_info
from interface.Grocery import Grocery_System
from interface.password_change_interface import Password_System
from interface.Edit_Employee import employee
from PIL import Image,ImageTk
from tkinter import ttk
from tkinter import messagebox
import datetime
global update_index
class Admin_System:
    def __init__(self,window):

        self.window = window

        self.FOODS = food_info()

        self.window.title("Admin Control Panel")
        self.window.geometry('1450x790+0+0')
        self.window.resizable("false", "false")

        def time():
            now = datetime.datetime.now()
            self.date = (now.strftime("%I:%M:%S:%p"))
            self.daa = (now.strftime("%H:%M:%S '/n' %d-%m-%y"))
            self.clock_label = Label(self.window, font=('Radioland', 25), fg='black', bg="White",text=self.date)
            self.clock_label.place(x=1216, y=45)
            self.clock_label.after(200, time)
        time()





        self.bg2 = ImageTk.PhotoImage(file="C:\\Users\\DELL\\Desktop\\python_projects\\admin.jpg")
        bg = Label(self.window, image=self.bg2).place(x=0,y=0, relwidth=1, relheight=1)

        self.name_label=Label(self.window,text="Item Name",font=("times new roman",20,"bold"),bg="white")
        self.name_label.place(x=120,y=129)

        self.name_entry = Entry(self.window,font=("times new roman",15,"bold"),highlightbackground="black",highlightthickness=3,bg="lightgray")
        self.name_entry.place(x=80,y=160)

        self.types_label = Label(self.window, text="Item Type", font=("times new roman", 20, "bold"),bg="white")
        self.types_label.place(x=520, y=129)

        self.types_entry = Entry(self.window, font=("times new roman", 15, "bold"),highlightbackground="black",highlightthickness=3,bg="lightgray")
        self.types_entry.place(x=478, y=160)

        self.price_label = Label(self.window,text="Item Price",font=("times new roman",20,"bold"),bg="white")
        self.price_label.place(x=920,y=129)

        self.price_entry = Entry(self.window,font=("times new roman",15,"bold"),highlightbackground="black",highlightthickness=3,bg="lightgray")
        self.price_entry.place(x=880,y=160)

        self.search_Box = Entry(self.window, font=("times new roman", 15, "bold"), highlightbackground="black",highlightthickness=1)
        self.search_Box.place(x=720, y=255)

        self.combo_searchfrom = ttk.Combobox(self.window, font=("times new roman", 15), state="readonly", justify=CENTER)
        self.combo_searchfrom.place(x=300, y=258, width=250, height=31)
        self.combo_searchfrom["values"] = ("Foods", "Cosmetics", "Breads")

        self.reset = PhotoImage(file="admin_reset.png")
        self.top_reset = Button(self.window,image = self.reset,bg="white",borderwidth=0, font=("times new roman", 15, "bold"),command=self.top_entry_reset)
        self.top_reset.place(x=1150, y=121, width=80, height=75)

        #self.logout_img = PhotoImage(file="admin_logout.png")
        #self.logout2 = Button(self.window,image=self.logout_img,bg="white",borderwidth=0,font=("times new roman", 15, "bold"),command=self.logout)
        #self.logout2.place(x=40, y=35, width=150, height=60)

        self.add_img = PhotoImage(file="admin_add.png")
        self.add_foods = Button(self.window,text="Add",bg="white",image=self.add_img,borderwidth=0,font=("times new roman",15,"bold"),command=self.Add)
        self.add_foods.place(x=64,y=650,width=80,height=90)

        self.update_img = PhotoImage(file="admin_update.png")
        self.update_food = Button(self.window,bg="white",borderwidth=0,image=self.update_img,font=("times new roman", 15, "bold"),command=self.update_foods)
        self.update_food.place(x=204, y=650, width=80, height=90)

        self.delete_img = PhotoImage(file="admin_delete.png")
        self.delete_food = Button(self.window,bg="white",borderwidth=0,image=self.delete_img,font=("times new roman", 15, "bold"),command=self.delete_foods)
        self.delete_food.place(x=344, y=650, width=80, height=90)

        self.update_index = ""

        self.add_cosmetic = Button(self.window, text="Add",bg="white",image=self.add_img,borderwidth=0,font=("times new roman", 15, "bold"),command=self.Add_Cosmetics)
        self.add_cosmetic.place(x=525, y=650, width=80, height=90)

        self.Update_cosmetic = Button(self.window,bg="white",borderwidth=0,image=self.update_img, font=("times new roman", 15, "bold"),command=self.update_cosmetics)
        self.Update_cosmetic.place(x=660, y=650, width=80, height=90)

        self.delete_cosmetic = Button(self.window,bg="white",borderwidth=0,image=self.delete_img,font=("times new roman", 15, "bold"),command=self.delete_cosmetics)
        self.delete_cosmetic.place(x=806, y=650, width=80, height=90)

        self.add_bread = Button(self.window, text="Add",bg="white",image=self.add_img,borderwidth=0, font=("times new roman", 15, "bold"),command=self.Add_Bread)
        self.add_bread.place(x=990, y=650, width=80, height=90)

        self.update_bread = Button(self.window,bg="white",borderwidth=0,image=self.update_img,font=("times new roman", 15, "bold"),command=self.update_breads)
        self.update_bread.place(x=1125, y=650, width=80, height=90)

        self.delete_bread = Button(self.window,bg="white",borderwidth=0,image=self.delete_img,font=("times new roman", 15, "bold"),command=self.delete_breads)
        self.delete_bread.place(x=1272, y=650, width=80, height=90)

        self.search_img = PhotoImage(file="search.png")
        self.search_Button= Button(self.window,image=self.search_img, bg="white",borderwidth=0,font=("times new roman", 15, "bold"),command=self.search)
        self.search_Button.place(x=1100, y=219, width=80, height=70)


        self.foods_tree = ttk.Treeview(self.window, columns=("name", "type", "price"))
        self.foods_tree.place(x=50, y=340, width=375, height=300)
        self.foods_tree['show'] = 'headings'
        self.foods_tree.column("name", width=100)
        self.foods_tree.column("type", width=100)
        self.foods_tree.column("price", width=50)

        self.foods_tree.heading("name", text="Name")
        self.foods_tree.heading("type", text="Type")
        self.foods_tree.heading("price", text="Price")

        self.show_foods_tree()
        self.menu()

        self.foods_tree_scroll = ttk.Scrollbar(self.window, orient="vertical",command=self.foods_tree.yview)
        self.foods_tree.configure(yscroll=self.foods_tree_scroll.set)
        self.foods_tree_scroll.place(x=420, y=340, width=40, height=300)

        self.cosmetic_tree = ttk.Treeview(self.window, columns=("name", "type", "price"))
        self.cosmetic_tree.place(x=512, y=340, width=375, height=300)
        self.cosmetic_tree['show'] = 'headings'
        self.cosmetic_tree.column("name", width=100)
        self.cosmetic_tree.column("type", width=100)
        self.cosmetic_tree.column("price", width=50)

        self.cosmetic_tree.heading("name", text="Name")
        self.cosmetic_tree.heading("type", text="Type")
        self.cosmetic_tree.heading("price", text="Price")

        self.show_cosmetics_tree()

        self.cosmetic_tree_scroll = ttk.Scrollbar(self.window, orient="vertical", command=self.cosmetic_tree.yview)
        self.cosmetic_tree.configure(yscroll=self.cosmetic_tree_scroll.set)
        self.cosmetic_tree_scroll.place(x=882, y=340, width=40, height=300)



        self.bread_tree = ttk.Treeview(self.window, columns=("name", "type", "price"))
        self.bread_tree.place(x=975, y=340, width=375, height=300)
        self.bread_tree['show'] = 'headings'
        self.bread_tree.column("name", width=100)
        self.bread_tree.column("type", width=100)
        self.bread_tree.column("price", width=50)

        self.show_Bread_tree()

        self.bread_tree.heading("name", text="Name")
        self.bread_tree.heading("type", text="Type")
        self.bread_tree.heading("price", text="Price")

        self.bread_tree_scroll = ttk.Scrollbar(self.window, orient="vertical", command=self.bread_tree.yview)
        self.bread_tree.configure(yscroll=self.bread_tree_scroll.set)
        self.bread_tree_scroll.place(x=1340, y=340, width=40, height=300)

    def exception(self):
        try:
            self.price_string = self.price_entry.get()
            self.price_int = float(self.price_string)
        except ValueError:
            messagebox.showerror("Error","Price can't be strings!!!!!")
            self.price_entry.delete(0,END)
            return True

    def empty_exception(self):
        if self.name_entry.get() == "" or self.types_entry.get() == "" or self.price_entry.get() == "":
            messagebox.showerror("Error", "Entries are empty!!!")
            return True
            pass


    def Employment(self):
        self.staff = Toplevel(self.window)
        Grocery_System(self.staff)


    def Add(self):

        if self.empty_exception():
            return True

        elif self.exception():
            return True


        else:
            name0 = self.name_entry.get()
            type0 = self.types_entry.get()
            price0 = self.price_entry.get()

            if self.FOODS.Add(name0,type0,price0):
                messagebox.showinfo("Congratulation", "Items Added Successfully Admin!")
                self.show_foods_tree()

                self.top_entry_reset()


    def update_foods(self):
        global update_index

        if self.empty_exception():
            return True

        elif self.update_index == "":
            messagebox.showerror("Error", "please select the foods item first")

        elif self.exception():
            return True

        else:
            name = self.name_entry.get()
            type = self.types_entry.get()
            rate = self.price_entry.get()

            if self.FOODS.update_foods(self.update_index, name, type, rate):
                messagebox.showinfo("Item", "food updated")

                self.top_entry_reset()

                self.show_foods_tree()
                self.update_index = ""
            else:
                messagebox.showerror("Error", "cannot be updated!!!!")

    def delete_foods(self):
        global update_index

        if len(self.foods_tree.get_children()) == 0:
            messagebox.showerror("Error","Can't be deleted because nothing is in the cart")

        elif self.update_index == "":
            messagebox.showerror("Error", "please select the foods item first")

        else:
            name = self.name_entry.get()
            type = self.types_entry.get()
            rate = self.price_entry.get()

            if self.FOODS.delete_foods(name,type,rate):
                messagebox.showinfo("Item", "foods items deleted")
                self.top_entry_reset()

                self.show_foods_tree()
                self.update_index = ""

            else:
                messagebox.showerror("Error", "cannot be deleted!!!!")

    def show_foods_tree(self):
        self.foods_tree.delete(*self.foods_tree.get_children())
        data = self.FOODS.show_item()
        for i in data:
            self.foods_tree.insert("", "end", text=i[0], value=(i[1],i[2],i[3]))
            self.foods_tree.bind("<Double-1>", self.on_foods_select)

    def search(self):
        name = self.search_Box.get()
        if self.combo_searchfrom.get() == "" or self.search_Box.get() == "":
            messagebox.showerror("Error","Please fill the entries to search")
        elif self.combo_searchfrom.get() == "Cosmetics":
            self.cosmetic_tree.delete(*self.cosmetic_tree.get_children())
            data = self.FOODS.search_items(name)
            for i in data:
                self.cosmetic_tree.insert("","end",text=i[0], value=(i[1],i[2],i[3]))
                self.cosmetic_tree.bind("<Double-1>", self.on_cosmetic_select)
        elif self.combo_searchfrom.get() == "Foods":
            self.foods_tree.delete(*self.foods_tree.get_children())
            data = self.FOODS.search_foods(name)
            for i in data:
                self.foods_tree.insert("", "end", text=i[0], value=(i[1], i[2], i[3]))
                self.foods_tree.bind("<Double-1>", self.on_foods_select)
        elif self.combo_searchfrom.get() == "Breads":
            self.bread_tree.delete(*self.bread_tree.get_children())
            data = self.FOODS.search_breads(name)
            for i in data:
                self.bread_tree.insert("", "end", text=i[0], value=(i[1], i[2], i[3]))
                self.bread_tree.bind("<Double-1>", self.on_bread_select)




    def on_foods_select(self,event):
        selected_row = self.foods_tree.selection()[0]
        selected_item = self.foods_tree.item(selected_row,'values')
        self.update_index = self.foods_tree.item(selected_row,'text')

        global update_index
        self.name_entry.delete(0, END)
        self.name_entry.insert(0, selected_item[0])

        self.types_entry.delete(0, END)
        self.types_entry.insert(0, selected_item[1])

        self.price_entry.delete(0, END)
        self.price_entry.insert(0, selected_item[2])

    def Add_Cosmetics(self):

        if self.empty_exception():
            return True

        elif self.exception():
            return True

        else:
            name0 = self.name_entry.get()
            type0 = self.types_entry.get()
            price0 = self.price_entry.get()

            if self.FOODS.Add_Cosmetic(name0,type0,price0):
                messagebox.showinfo("Congratulation", "Items Added Successfully Admin!")
                self.show_cosmetics_tree()

                self.top_entry_reset()



    def logout (self):
        from interface.login_ import Sign
        self.ttt = Toplevel(self.window)
        self.window.withdraw()
        Sign(self.ttt)

    def update_cosmetics(self):
        global update_index

        if self.empty_exception():
            return True

        elif self.update_index == "":
            messagebox.showerror("Error", "please select the cosmetics item first")

        elif self.exception():
            return True

        else:
            name = self.name_entry.get()
            type = self.types_entry.get()
            rate = self.price_entry.get()

            if self.FOODS.update_cosmetics(self.update_index, name, type, rate):
                messagebox.showinfo("Item", "cosmetic updated")

                self.top_entry_reset()

                self.show_cosmetics_tree()
                self.update_index = ""

            else:
                messagebox.showerror("Error", "cannot be updated!!!!")

    def delete_cosmetics(self):
        global update_index

        if len(self.cosmetic_tree.get_children()) == 0:
            messagebox.showerror("Error","Can't be deleted because nothing is in the cart")

        elif self.update_index == "":
            messagebox.showerror("Error", "please select the cosmetics item first")

        else:
            name = self.name_entry.get()
            type = self.types_entry.get()
            rate = self.price_entry.get()

            if self.FOODS.delete_cosmetics(name,type,rate):
                messagebox.showinfo("Item", "cosmetic items deleted")
                self.top_entry_reset()

                self.show_cosmetics_tree()
                self.update_index = ""

            else:
                messagebox.showerror("Error", "cannot be deleted!!!!")

    def show_cosmetics_tree(self):
        self.cosmetic_tree.delete(*self.cosmetic_tree.get_children())
        data = self.FOODS.show_cosmetic()
        for i in data:
            self.cosmetic_tree.insert("", "end", text=i[0], value=(i[1],i[2],i[3]))
            self.cosmetic_tree.bind("<Double-1>", self.on_cosmetic_select)

    def on_cosmetic_select(self,event):
        selected_row = self.cosmetic_tree.selection()[0]
        selected_item = self.cosmetic_tree.item(selected_row,'values')
        self.update_index = self.cosmetic_tree.item(selected_row,'text')

        global update_index
        self.name_entry.delete(0, END)
        self.name_entry.insert(0, selected_item[0])

        self.types_entry.delete(0, END)
        self.types_entry.insert(0, selected_item[1])

        self.price_entry.delete(0, END)
        self.price_entry.insert(0, selected_item[2])



    def Add_Bread(self):

        if self.empty_exception():
            return True

        elif self.exception():
            return True

        else:
            name0 = self.name_entry.get()
            type0 = self.types_entry.get()
            price0 = self.price_entry.get()

            if self.FOODS.Add_Bread(name0,type0,price0):
                messagebox.showinfo("Congratulation", "Items Added Successfully Admin!")
                self.show_Bread_tree()

                self.top_entry_reset()

    def update_breads(self):
        global update_index

        if self.empty_exception():
            return True

        elif self.update_index == "":
            messagebox.showerror("Error", "please select the breads item first")

        elif self.exception():
            return True

        else:
            name = self.name_entry.get()
            type = self.types_entry.get()
            rate = self.price_entry.get()

            if self.FOODS.update_breads(self.update_index, name, type, rate):
                messagebox.showinfo("Item", "bread updated")

                self.top_entry_reset()

                self.show_Bread_tree()
                self.update_index = ""
            else:
                messagebox.showerror("Error", "cannot be updated!!!!")

    def delete_breads(self):
        global update_index

        if len(self.bread_tree.get_children()) == 0:
            messagebox.showerror("Error","Can't be deleted because nothing is in the cart")

        elif self.update_index == "":
            messagebox.showerror("Error", "please select the breads item first")

        else:
            name = self.name_entry.get()
            type = self.types_entry.get()
            rate = self.price_entry.get()

            if self.FOODS.delete_breads(name,type,rate):
                messagebox.showinfo("Item", "breads items deleted")
                self.top_entry_reset()

                self.show_Bread_tree()
                self.update_index = ""

            else:
                messagebox.showerror("Error", "cannot be deleted!!!!")

    def show_Bread_tree(self):
        self.bread_tree.delete(*self.bread_tree.get_children())
        data = self.FOODS.show_bread()
        for i in data:
            self.bread_tree.insert("", "end", text=i[0], value=(i[1],i[2],i[3]))
            self.bread_tree.bind("<Double-1>", self.on_bread_select)

    def on_bread_select(self,event):
        selected_row = self.bread_tree.selection()[0]
        selected_item = self.bread_tree.item(selected_row,'values')
        self.update_index = self.bread_tree.item(selected_row,'text')

        global update_index
        self.name_entry.delete(0, END)
        self.name_entry.insert(0, selected_item[0])

        self.types_entry.delete(0, END)
        self.types_entry.insert(0, selected_item[1])

        self.price_entry.delete(0, END)
        self.price_entry.insert(0, selected_item[2])

    def top_entry_reset(self):
        self.name_entry.delete(0,END)
        self.types_entry.delete(0,END)
        self.price_entry.delete(0,END)
        self.search_Box.delete(0,END)
        self.show_foods_tree()
        self.show_cosmetics_tree()
        self.show_Bread_tree()
        self.combo_searchfrom.set('')

    def menu(self):
        my_menu = Menu(self.window)
        self.window.config(menu=my_menu)
        file_menu = Menu(my_menu)
        my_menu.add_cascade(label = "File", menu = file_menu)
        file_menu.add_cascade(label = "Change Password",command=self.change_Password)
        file_menu.add_cascade(label="Edit Employee",command=self.employee)
        file_menu.add_cascade(label="Customer brought")
        file_menu.add_separator()
        file_menu.add_cascade(label="Logout",command=self.logout)
        file_menu.add_separator()
        file_menu.add_cascade(label="Exit",command=self.window.quit)
        #self.window.grab_set()

    def change_Password(self):
        self.p_wind = Toplevel(self.window)
        Password_System(self.p_wind)
    def employee(self):
        self.e_wind = Toplevel(self.window)
        employee(self.e_wind)



                    #self.window_bread = Toplevel(self.window)
                    #self.info_food = food_info()
                    #self.window_bread.title("Foods Store")
                    #self.window_bread.geometry('1350x800')
                    #self.window_bread.resizable("false", "false")

                    #self.wn_back = PhotoImage(file="Bread_store.png")
                    #bg3 = Label(self.window_bread, image=self.wn_back).place(x=0, y=0, relwidth=1, relheight=1)







def main():
    window = Tk()
    obj = Admin_System(window)
    window.mainloop()
if __name__ == '__main__':
    main()
