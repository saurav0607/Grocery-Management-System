
for i in orders:
    order = self.grocery_tree.item(i, 'values')
    # items = order[0] + "\t" +order[1] + "\t" +order[2] + "\t" + order[3] + "\t" +order[4]

    self.bill_tree.insert("", "end", text=i[0], values=(order[0], order[1], order[2], order[3], order[4]))
    # self.l = Label(self.frame,text = items,bg="White")
    # self.l.place(x=0,y=00)
    # print(items)
    amnt = float(order[2]) * float(order[3])
    total += amnt
    label_price = Label(self.frame, text=total, bg="White", font=("times new roman", 11, "bold"))
    label_price.place(x=380, y=520)
    print(amnt)

data = len(self.grocery_tree.get_children())
ddd = 0
for i in range(0, data + 1):
    print(i)

    total_number = Label(self.frame, text=i, bg="White", font=("times new roman", 11, "bold"))
    total_number.place(x=280, y=520)

    self.word = Label(self.frame, text="--------------------------------------------------",
                      font=("times new roman", 20, "bold"), bg="white")
    self.word.place(x=0, y=490)

    lb_tot = Label(self.frame, text="Total = ", bg="White", font=("times new roman", 11, "bold"))
    lb_tot.place(x=320, y=520)

    lb_tot_quan = Label(self.frame, text="Total Items = ", bg="White", font=("times new roman", 11, "bold"))
    lb_tot_quan.place(x=180, y=520)

self.img = PhotoImage(file="Logo_Kollywood.png")

ddd = self.customer_Name_Entry.get()

self.koly_btn_title = Button(self.frame, bg="White", image=self.img, borderwidth=0)
self.koly_btn_title.place(x=176, y=8, height=100, width=100)

self.word = Label(self.frame, text="--------------------------------------------------",
                  font=("times new roman", 20, "bold"), bg="white")
self.word.place(x=0, y=110)

self.word = Label(self.frame, text="--------------------------------------------------",
                  font=("times new roman", 20, "bold"), bg="white")
self.word.place(x=0, y=140)

self.cu_name = Label(self.frame, text="Customer Name =", bg="White", font=("times new roman", 11, "bold"))
self.cu_name.place(x=20, y=135)

self.name_grab = Label(self.frame, text=ddd, font=("times new roman", 11, "bold"), bg="white")
self.name_grab.place(x=150, y=135)
