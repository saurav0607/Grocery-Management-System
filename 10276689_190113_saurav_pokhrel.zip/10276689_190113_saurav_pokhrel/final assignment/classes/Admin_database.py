import mysql.connector
class Foods:
    def __init__(self):
        self.my_connection = mysql.connector.connect(user="root", password="", host="localhost", database='assignment2')
        self.my_cursor = self.my_connection.cursor()

    def Add_up_del(self,qry,values):
        self.my_cursor.execute(qry,values)
        self.my_connection.commit()

    def show_data(self,qry):
        self.my_cursor.execute(qry)
        data = self.my_cursor.fetchall()
        return data

