import unittest
from classes.Admin_infp import  food_info
from classes.register_info import Info
class TestStringMethods(unittest.TestCase):

    def test_Confirm(self):
       result = food_info().Confirm("name", "types", 2,3, 123, "cutomers_name")
       self.assertTrue(result)

   # name, phone, cmbo_box, address, password, username
    def test_Register(self):
        resukt = Info().Register("name","26" ,"cmbo_box", "address", "password","username")
        self.assertTrue(resukt)

    def test_show_bread(self):
        result=food_info().show_bread()
        values=[(2, 'Krishna', 'Muffin', '60'), (3, 'Krishna', 'Bread', '60'), (4, 'Krishna', 'Doughnot', '120'), (5, 'Rajesh', 'Pauroti', '35')]
        self.assertEqual(result,values)

    def test_Login(self):
        result = Info().Login("softwarica","softwarica")
        self.assertEqual(result,1)

    def test_Update_foods(self):
        result = food_info().update_foods(1,"name0" , "types0" , "rate0")
        self.assertTrue(result)

