from tkinter import *
from interface.login_ import Sign
class Sign1:
    def __init__(self,window):

#===Sign_In_Window====================================================================================================:
#=======To_Close_Previous_Window======================================================================================
        #self.window.withdraw()
        self.window=window
        self.window.title("Sign_in")
        self.window.geometry('550x650')
        self.window.resizable("false","false")
        self.button=Button(self.window,text="OPEN",command=self.toplevel)
        self.button.grid(row=0,column=0)


    def toplevel(self):
        self.ur=Toplevel(self.window)
        Sign(self.ur)




def main():
    window = Tk()
    obj = Sign1(window)
    window.mainloop()
if __name__ == '__main__':
    main()
