from classes.Admin_database import Foods


class food_info:
    def __init__(self):
        self.name1 = []
        self.types1 = []
        self.quantity1 = []
        self.price1 = []
        self.username1 = []
        self.total1 = []

        self.my_food = Foods()

   
    def Add(self, name0,types0,price0):
        qry = "INSERT INTO admin_foods_database (name, types, price) VALUES (%s,%s,%s)"
        values = (name0, types0, price0)
        self.my_food.Add_up_del(qry,values)
        return True


    def search_items(self, key):
        qry = "SELECT * FROM admin_cosmetic_database WHERE name LIKE '" + key + "%'"
        all_items = self.my_food.show_data(qry)
        return all_items

    def Grocery_Foods_Search(self, key):
        qry = "SELECT * FROM admin_foods_database WHERE name LIKE '" + key + "%'"
        all_items = self.my_food.show_data(qry)
        return all_items

    def Grocery_Cosmetics_Search(self, key):
        qry = "SELECT * FROM admin_cosmetic_database WHERE name LIKE '" + key + "%'"
        all_items = self.my_food.show_data(qry)
        return all_items

    def Grocery_Breads_Search(self, key):
        qry = "SELECT * FROM admin_bread_database WHERE name LIKE '" + key + "%'"
        all_items = self.my_food.show_data(qry)
        return all_items

    def search_foods(self, key):
        qry = "SELECT * FROM admin_foods_database WHERE name LIKE '" + key + "%'"
        all_items = self.my_food.show_data(qry)
        return all_items

    def admin(self, key):
        qry = "SELECT User FROM sign_up_info order by  User LIKE '" + key + "%'"
        all_items = self.my_food.show_data(qry)
        return all_items

    def search_breads(self, key):
        qry = "SELECT * FROM admin_bread_database WHERE name LIKE '" + key + "%'"
        all_items = self.my_food.show_data(qry)
        return all_items


    def show_item(self):
        qry = "SELECT * FROM admin_foods_database"
        all_items = self.my_food.show_data(qry)
        return all_items

    def show_employee(self):
        qry = "SELECT * FROM sign_up_info"
        all_items = self.my_food.show_data(qry)
        return all_items

    def admin_info(self):
        qry = "SELECT * FROM admin"
        all_items = self.my_food.show_data(qry)
        return all_items


    def Add_Cosmetic(self, name0,types0,price0):
        qry = "INSERT INTO admin_cosmetic_database (name, types, price) VALUES (%s,%s,%s)"
        values = (name0, types0, price0)
        self.my_food.Add_up_del(qry,values)
        return True

    def Add_new_passwd(self, name, password):
        qry = "INSERT INTO admin (User, Password) VALUES (%s,%s)"
        values = (name, password)
        self.my_food.Add_up_del(qry,values)
        return True


    def show_cosmetic(self):
        qry = "SELECT * FROM admin_cosmetic_database"
        all_items = self.my_food.show_data(qry)
        return all_items

    def Add_Bread(self, name0,types0,price0):
        qry = "INSERT INTO admin_bread_database (name, types, price) VALUES (%s,%s,%s)"
        values = (name0, types0, price0)
        self.my_food.Add_up_del(qry,values)
        return True


    def show_bread(self):
        qry = "SELECT * FROM admin_bread_database"
        all_items = self.my_food.show_data(qry)
        return all_items


    def cart_foods(self, name, types,quantity,username,rate,total):
        self.name1.append(name)
        self.types1.append(types)
        self.quantity1.append(quantity)
        self.price1.append(rate)
        self.username1.append(username)
        self.total1.append(total)
        return True


    def show_cart(self):
        all_cart = []
        for i in range(len(self.name1)):
            all_cart.append((self.name1[i],self.types1[i],self.quantity1[i],self.price1[i],self.total1[i],self.username1[i]))
        return all_cart

    def show_bill(self):
        all_cart = []
        for i in range(len(self.name1)):
            all_cart.append((self.name1[i], self.types1[i], self.quantity1[i], self.price1[i], self.total1[i]))
        return all_cart


    def update_cart(self,index,name,type,quantity,rate,total):
        self.name1[index] = name
        self.types1[index] = type
        self.quantity1[index] = quantity
        self.price1[index] = rate
        self.total1[index] = total
        return True

    def remove_selected_cart(self,name,type,quantity,rate):
        self.name1.remove(name)
        self.types1.remove(type)
        self.quantity1.remove(quantity)
        self.price1.remove(rate)
        return True


    def Confirm(self, name, types, quantity, price, total_price, cutomers_name):
        qry = "INSERT INTO customer_brought (name, type, quantity, prce, total_price, customer_name) VALUES (%s,%s,%s,%s,%s,%s)"
        values = (name, types, quantity, price, total_price, cutomers_name)
        self.my_food.Add_up_del(qry, values)
        return True


    def update_foods(self, row, name0 , types0 , rate0):
        qry = "UPDATE admin_foods_database SET name = %s, types= %s, price = %s WHERE id = %s"
        values = (name0, types0, rate0, row)
        self.my_food.Add_up_del(qry,values)
        return True

    def update_informations(self, row, name, password):
        qry = "UPDATE admin SET User = %s, Password= %s WHERE id = %s"
        values = (name, password,row)
        self.my_food.Add_up_del(qry,values)
        return True

    def update_employee(self, row, name, phone, age, address, password):
        qry = "UPDATE sign_up_info SET User = %s, Phone = %s, Gender = %s, Address = %s, Password= %s WHERE id = %s"
        values = (name, phone, age, address, password,row)
        self.my_food.Add_up_del(qry,values)
        return True


    def update_cosmetics(self, row, name0 , types0 , rate0):
        qry = "UPDATE admin_cosmetic_database SET name = %s, types= %s, price = %s WHERE id = %s"
        values = (name0, types0, rate0, row)
        self.my_food.Add_up_del(qry,values)
        return True


    def update_breads(self, row, name0 , types0 , rate0):
        qry = "UPDATE admin_bread_database SET name = %s, types= %s, price = %s WHERE id = %s"
        values = (name0, types0, rate0, row)
        self.my_food.Add_up_del(qry,values)
        return True


    def delete_cosmetics(self,name0,types0,price0):
        qry = "DELETE FROM admin_cosmetic_database WHERE types =%s and name =%s and price =%s"
        values = (types0,name0,price0)
        self.my_food.Add_up_del(qry,values)
        return True

    def delete_employee(self,name,phone,address,password):
        qry = "DELETE FROM sign_up_info WHERE User =%s and Phone =%s and Address =%s and Password =%s"
        values = (name,phone,address,password)
        self.my_food.Add_up_del(qry,values)
        return True


    def delete_foods(self,name0,types0,price0):
        qry = "DELETE FROM admin_foods_database WHERE types =%s and name =%s and price =%s"
        values = (types0,name0,price0)
        self.my_food.Add_up_del(qry,values)
        return True


    def delete_breads(self,name0,types0,price0):
        qry = "DELETE FROM admin_bread_database WHERE types =%s and name =%s and price =%s"
        values = (types0,name0,price0)
        self.my_food.Add_up_del(qry,values)
        return True
