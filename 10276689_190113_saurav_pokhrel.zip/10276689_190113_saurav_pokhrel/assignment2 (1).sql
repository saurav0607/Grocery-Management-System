-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 04, 2020 at 10:40 AM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `assignment2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `User` varchar(100) NOT NULL,
  `Password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `User`, `Password`) VALUES
(1, 'Admin', 'Toor'),
(2, 'test', 'test');

-- --------------------------------------------------------

--
-- Table structure for table `admin_bread_database`
--

CREATE TABLE `admin_bread_database` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `types` varchar(50) NOT NULL,
  `price` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_bread_database`
--

INSERT INTO `admin_bread_database` (`id`, `name`, `types`, `price`) VALUES
(2, 'Krishna', 'Muffin', '60'),
(3, 'Krishna', 'Bread', '60'),
(4, 'Krishna', 'Doughnot', '120'),
(5, 'Rajesh', 'Pauroti', '35');

-- --------------------------------------------------------

--
-- Table structure for table `admin_cosmetic_database`
--

CREATE TABLE `admin_cosmetic_database` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `types` varchar(50) NOT NULL,
  `price` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_cosmetic_database`
--

INSERT INTO `admin_cosmetic_database` (`id`, `name`, `types`, `price`) VALUES
(3, 'Garnier', 'Facewash', '180'),
(5, 'Henna', 'Hair Colour', '60'),
(6, 'Lakme', 'Foundation', '2000'),
(7, 'Garnier', 'Cream', '180');

-- --------------------------------------------------------

--
-- Table structure for table `admin_foods_database`
--

CREATE TABLE `admin_foods_database` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `types` varchar(50) NOT NULL,
  `price` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_foods_database`
--

INSERT INTO `admin_foods_database` (`id`, `name`, `types`, `price`) VALUES
(3, 'Krishna bhog', 'Chyamal', '1200'),
(4, 'Sunflower', 'Oil', '120'),
(5, 'Sunflower', 'Oil', '180'),
(7, 'Century', 'Masala', '200');

-- --------------------------------------------------------

--
-- Table structure for table `customer_brought`
--

CREATE TABLE `customer_brought` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL,
  `prce` double NOT NULL,
  `total_price` double NOT NULL,
  `customer_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customer_brought`
--

INSERT INTO `customer_brought` (`id`, `name`, `type`, `quantity`, `prce`, `total_price`, `customer_name`) VALUES
(1, '0', '0', 4, 2, 8, '0'),
(2, '0', '0', 6, 4, 24, '0'),
(3, '0', '0', 10, 5, 50, '0'),
(4, '0', '0', 4, 60, 240, '0'),
(5, '0', '0', 4, 4, 16, '0'),
(6, '0', '0', 6, 4, 24, '0'),
(7, '0', '0', 8, 5, 40, '0'),
(8, 'd', 'dd', 4, 2, 8, 'softwarica'),
(9, 'Century', 'Masala', 4, 60, 240, 'softwarica'),
(10, 'asd', 'asd', 4, 4, 16, 'softwarica'),
(11, 'df', 'f', 4, 5, 20, 'softwarica'),
(12, 'Sunflower', 'Oil', 4, 180, 720, 'Saurav'),
(13, 'Century', 'Masala', 8, 60, 480, 'Saurav'),
(14, 'Garnier', 'Facewash', 8, 180, 1440, 'Saurav'),
(15, 'Henna', 'Hair Colour', 8, 60, 480, 'Saurav'),
(16, 'Rajesh', 'Pauroti', 4, 35, 140, 'Saurav'),
(17, 'Krishna', 'Doughnot', 6, 120, 720, 'Saurav'),
(18, 'Sunflower', 'Oil', 4, 180, 720, 'Saurav'),
(19, 'Sunflower', 'Oil', 5, 120, 600, 'Saurav'),
(20, 'Henna', 'Hair Colour', 4, 60, 240, 'Saurav'),
(21, 'Krishna', 'Bread', 5, 60, 300, 'Saurav'),
(22, 'Sunflower', 'Oil', 4, 180, 720, 'santosh'),
(23, 'Henna', 'Hair Colour', 4, 60, 240, 'santosh'),
(24, 'Lakme', 'Foundation', 4, 2000, 8000, 'santosh'),
(25, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(27, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(28, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(29, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(30, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(31, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(32, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(33, 'Sunflower', 'Oil', 3, 180, 540, 's'),
(34, 'Century', 'Masala', 3, 60, 180, 's'),
(35, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(36, 'Sunflower', 'Oil', 4, 120, 480, 's'),
(37, 'Sunflower', 'Oil', 4, 180, 720, 's'),
(38, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(39, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(40, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(41, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(42, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(43, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(44, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(45, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(46, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(47, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(48, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(49, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(50, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(51, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(52, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(53, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(54, 'Krishna bhog', 'Chyamal', 4, 1200, 4800, 'Coventry'),
(55, 'Krishna', 'Doughnot', 10, 120, 1200, 'Coventry'),
(56, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(57, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(58, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(59, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(60, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(61, 'Sunflower', 'Oil', 4, 120, 480, 'Saurav'),
(62, 'Sunflower', 'Oil', 4, 180, 720, 'Saurav'),
(63, 'Lakme', 'Foundation', 4, 2000, 8000, 'Saurav'),
(64, 'Henna', 'Hair Colour', 4, 60, 240, 'Saurav'),
(65, 'Rajesh', 'Pauroti', 6, 35, 210, 'Saurav'),
(66, 'Krishna', 'Bread', 8, 60, 480, 'Saurav'),
(67, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(68, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(69, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(70, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(71, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(72, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(73, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(74, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(75, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(76, 'name', 'types', 2, 3, 123, 'cutomers_name'),
(77, 'name', 'types', 2, 3, 123, 'cutomers_name');

-- --------------------------------------------------------

--
-- Table structure for table `sign_up_info`
--

CREATE TABLE `sign_up_info` (
  `id` int(11) NOT NULL,
  `User` varchar(100) NOT NULL,
  `Phone` varchar(50) NOT NULL,
  `Gender` varchar(10) NOT NULL,
  `Address` varchar(20) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `username` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sign_up_info`
--

INSERT INTO `sign_up_info` (`id`, `User`, `Phone`, `Gender`, `Address`, `Password`, `username`) VALUES
(55, 'soft', '9817990699', 'Male', 's', 'cov', 'cov'),
(56, 'ss', '9817990699', 'Male', 's', 's', 'cov'),
(57, 'soksds', '9817990699', 'Male', 'Dillibazar', 'softwarica', 'softwarica'),
(58, 'name', '26', 'cmbo_box', 'address', 'password', 'username'),
(59, 'name', '26', 'cmbo_box', 'address', 'password', 'username'),
(60, 'name', '26', 'cmbo_box', 'address', 'password', 'username');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_bread_database`
--
ALTER TABLE `admin_bread_database`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_cosmetic_database`
--
ALTER TABLE `admin_cosmetic_database`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_foods_database`
--
ALTER TABLE `admin_foods_database`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_brought`
--
ALTER TABLE `customer_brought`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sign_up_info`
--
ALTER TABLE `sign_up_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin_bread_database`
--
ALTER TABLE `admin_bread_database`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `admin_cosmetic_database`
--
ALTER TABLE `admin_cosmetic_database`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `admin_foods_database`
--
ALTER TABLE `admin_foods_database`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `customer_brought`
--
ALTER TABLE `customer_brought`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `sign_up_info`
--
ALTER TABLE `sign_up_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
